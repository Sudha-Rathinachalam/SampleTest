dut=$1
testcase=$2
#RELEASE_NOTES=$(cat $BUILD_NUMBER.html)
sleep 30s
sshpass -p facebook scp -o StrictHostKeyChecking=no -r root@10.1.1.10:/root/$dut/$testcase /home/facebook/$dut/
sshpass -p pass\!Q\@W\#E sudo chmod 777 /home/facebook/$dut/$testcase
sshpass -p facebook scp -o StrictHostKeyChecking=no -r root@10.1.1.10:/root/$dut/csv_dynamic.csv /home/facebook/$dut/
sshpass -p pass\!Q\@W\#E sudo chmod 777 /home/facebook/$dut/csv_dynamic.csv
#sshpass -p pass\!Q\@W\#E python /home/facebook/insert_test_suite_table.py /home/facebook/$dut/$testcase /home/facebook/$dut/csv_dynamic.csv /home/facebook/$dut/html_final_report.csv
python /home/facebook/insert_test_suite_table.py /home/facebook/$dut/$testcase /home/facebook/$dut/csv_dynamic.csv /home/facebook/$dut/html_final_report.csv 
sshpass -p pass\!Q\@W\#E python /home/facebook/writing_html.py /home/facebook/$dut/html_final_report.csv /home/facebook/$dut/html_report.html
sshpass -p pass\!Q\@W\#E sudo chmod 777 /home/facebook/$dut/html_report.html 

