import re
import csv
import sys
import os
import mysql.connector

rex = re.compile(r'(- name: )(.*)')
query_list = []
query_result_list = []

db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()
cur.execute("SELECT distinct(Date) FROM UBMCT_YV2_Test_Suite order by Date DESC")

date_result = cur.fetchall()
date_result_csv = csv.writer(open("/home/facebook/html_report_split_date.csv", "w+"))

for row in date_result:
    print("row csv value is {}".format(row))
    date_result_csv.writerow(row)
    
with open("/home/facebook/html_report_split.csv", "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    print("inside /home/facebook/html_report_split_date.csv")
    for row in csv_reader:
        print("row value in file is {}".format(row))
        for date_tuple in row:
            dbQuery_Pass="select count(Result) from Device_Dummy_Suite GROUP BY Date, Result HAVING Result='Passed' and Date={}".format("'" + date_tuple + "'") + "ORDER BY Date DESC"
            dbQuery_Fail="select count(Result) from Device_Dummy_Suite GROUP BY Date, Result HAVING Result='Failed' and Date={}".format("'" + date_tuple + "'") + "ORDER BY Date DESC"
	    dbQuery_TotalTestCases="select count(TestCases), Date as d from Device_Dummy_Suite where Date={}".format("'" + date_tuple + "'") + "ORDER BY Date DESC"
	    query_list=[dbQuery_Pass, dbQuery_Fail, dbQuery_TotalTestCases]
            append_string = ""
            count = 0
            for query in query_list:
                print("query is {}".format(query))
                cur.execute(query)
                result_table=cur.fetchall()
                print("result_table value is {}".format(result_table))
                for result in result_table:
                    print("result value is {}".format(result))
                    for item in result:
                        print("item value is {}".format(item))
                        if count == 0:
                            append_string = append_string + str(item)
                        else:
                            append_string = append_string + "," + str(item)
                count = count + 1
            query_result_list.append(append_string)

print(" query_result_list  value is {}".format(query_result_list))      

result_file_name = "/home/facebook/SQL_Select_Query_Result.csv" 

for rows in query_result_list:
    if os.path.exists(result_file_name):
        append_write = "a+"
    else:
        append_write = "w+"
    with open(result_file_name, append_write) as write_select_query:
        print("append_write is {}".format(append_write))
        print("row value before write {}".format(rows))
        write_select_query.write(rows + "\n")

db_con.commit()
db_con.close()
