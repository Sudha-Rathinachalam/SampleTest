import csv
import sys


#html_final_report = sys.argv[1]
#html_file_name = sys.argv[2]

i = 0

def input_csv_output_html(csv_file_name, html_file_name_to_save, html_format):
    global i    
    print("CSV file name is {}".format(csv_file_name))
    # Open the CSV file for reading

#    reader_html = csv.reader(open(csv_file_name, "r+"))
    # Create the HTML file
    with open(html_file_name_to_save + html_format, "w+") as f_html:
#    f_html = open(html_file_name_to_save + str(i) + html_format, "w+");
        f_html.write('<html>')
        f_html.write('<body>')
        f_html.write('<table border = "1">')
        f_html.write('<caption><b><h3>Regression Result</h3></b></caption>')
        f_html.write('<style> table, th, td { border: 1px solid black;}</style>')
        f_html.write('<colgroup> <col span="5" style="background-color:grey"> </colgroup>')
        f_html.write('<thead><tr><th>Date</th>'
			                      '   <th>Device</th>'
                                              '   <th>Test Suite</th>'
                                              '   <th>Test Case</th>'
                                              '   <th>Result</th>'
                                              '</tr>'
                                              '</thead>')
        i += 1
        print("Inside html")
        with open(csv_file_name, "r+") as reader_html:
            csv_reader = csv.reader(reader_html)
            print("csv file name inside read is : ".format(csv_reader))
        
#            f_html.write('<body>');
#            f_html.write('<tr>');
            for row in csv_reader:  # Read a single row from the CSV file
                print("Row inside html is {}").format(row)
                f_html.write('<tr>');
                for column in row:
                    f_html.write('<td>' + column + '</td>');
                    print("Column inside html is {}").format(column)
                 
#                f_html.write('<tbody>');
#                f_html.write('<tr>');  # Create a new row in the table
                f_html.write('<tr>');
            #		print("inside html")
                f_html.write('</tr>');
            f_html.write('</table>')
            f_html.write('</body>')
            f_html.write('</html>')
    
