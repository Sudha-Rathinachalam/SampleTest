#!/bin/bash
#echo "inside controller"

end_time=100
echo "$testsuitename"
#favacli.py run testsuite  --ignore-bom-check --db-creds /root/dbcreds -s $dut -f $test_suite
#favacli.py run testsuite  --ignore-bom-check --db-creds /root/dbcreds -s $dut -f $testsuitename
#job_id=$(mysql fava -se 'select id from job where data like "'$testsuitename'" order by id DESC limit 1;')
#echo $job_id
job_id=5170
state=$(mysql fava -se 'select state from job where id='$job_id' order by id DESC limit 1;')
echo $state
task_id=$(mysql fava -se 'select id from task where job_id='$job_id'')
echo $task_id
if [ "$state" = "queued" ]
then
   sleep 2m
   state=$(mysql fava -se 'select state from job where id='$job_id' order by id DESC limit 1;')
fi
if [ "$state" = "started" ]
then
   echo "inside first if"
   task_id=$(mysql fava -se 'select id from task where job_id='$job_id';')
   task_start_time=$(mysql fava -se 'select start from task where id='$task_id';')
   task_start_time_in_sec=$(mysql fava -se 'select UNIX_TIMESTAMP('$task_start_time');')
   current_time=$(mysql fava -se 'select UNIX_TIMESTAMP()')
   while [ "$state" = "started" ]
   do
     echo "inside while"
     sleep 5m
     state=$(mysql fava -se 'select state from job where id='$job_id' order by id DESC limit 1;')
     echo $state
     if [ "$state" = "started" ]
     then
        echo "before continue"
#        current_time=$(mysql fava -se 'select NOW();')
        current_time=$(mysql fava -se 'select UNIX_TIMESTAMP();')
#        current_time_in_sec=$(mysql fava -se 'select TIME_TO_SEC('$current_time');')
        total_time=$current_time-$task_start_time_in_sec
        task_state=$(mysql fava -se 'select state from task where id='$task_id';')
        if [ "$task_state" = "running" ] && [ "$total_time" > "$end_time" ]
        then
           test_case_name=$(mysql fava -se 'select name from task where id='$task_id';')
           echo "$job_id", "$task_id", "$test_case_name"
           echo "call Python or sh by passing the task id, job id and test case name"
        fi
        continue
     elif [ "$state" = "completed" ]
     then
        task_id=$(mysql fava -se 'select id from task where job_id='$job_id';')
        break
     fi
   done
fi
if [ "$state" = "killed" ]
then
   task_id=$(mysql fava -se 'select id from task where job_id='$job_id';')
fi
echo $task_id
task_state=$(mysql fava -se 'select state from task where job_id='$job_id' and state="stalled" order by id DESC limit 1;')
if [ "$task_state" = "stalled" ]
then
   sleep 5m
else
   echo $state
fi
