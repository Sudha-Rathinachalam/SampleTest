#!/usr/bin/bash


url=$(curl -s https://api.github.com/repos/Sudha-Rathinachalam/SampleTest/releases/latest \
  | grep browser_download_url \
  | grep PyYAML \
  | cut -d '"' -f 4)
echo $url
password="pass\!Q\@W\#E"
echo $password
echo $password | sudo -S wget $url
return_code=$(echo $?)
echo $return_code
if [ $return_code -eq 0 ]
then 
	echo "COMPLETED DOWNLOADING!"
        echo "COPYING THE FILE TO ODM /root/bin_tar/"
        sshpass -p Fac3b00k! scp -v -o "StrictHostKeyChecking=no" /var/lib/jenkins/github-downloader/*.tar.gz root@210.200.12.40:/root/bin_tar/
        echo "COPYING COMPLETED!"
else
	echo "DOWNLOAD FAILED"
fi

echo "done"
