function getDate() {
	const yesterday = new Date();
	yesterday.setDate(yesterday.getDate() - 1);
	let dd = yesterday.getDate(); 
	let mm = yesterday.getMonth() + 1; 
	const yyyy = yesterday.getFullYear(); 
	if (dd < 10) { 
	    dd = '0' + dd; 
	} 
	if (mm < 10) { 
	    mm = '0' + mm; 
	} 
	return `${mm}-${dd}-${yyyy}`
}

const baseUrl = 'https://raw.githubusercontent.com/Sudha-Rathinachalam/SampleTest/master/binaries/';

function getLatestDownloadUrl() {
	return `${baseUrl}${getDate()}.tar.gz`;
}

console.log(getLatestDownloadUrl());
