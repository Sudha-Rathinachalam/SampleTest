#!/usr/bin/bash

password="pass\!Q\@W\#E"
echo "DOWNLOADING THE TAR FILE FROM GITHUB"
echo $password | sudo -S ./github-downloader.sh https://github.com/Sudha-Rathinachalam/SampleTest/tree/master/binaries
return_code=$(echo $?)
echo $return_code
if [ $return_code -eq 0 ]
then
    echo "COMPLETED DOWNLOADING!"
fi
bin_tar_dir="/var/lib/jenkins/github-downloader/binaries/"
echo "getting the latest file"
latest_file=$(ls /var/lib/jenkins/github-downloader/binaries/ -t | tail -n 1)
echo $latest_file
echo "COPYING THE TAR FILE TO THE ODM SERVER"
sshpass -p Fac3b00k! scp -o "StrictHostKeyChecking=no" $bin_tar_dir/$latest_file root@210.200.12.40:/root/bin_tar/
ret_code=$(echo $?)
echo $ret_code
if [ $ret_code -eq 0 ]
then
    echo "COPYING COMPLETED!"
else
    echo "COPYING FAILED!"
fi

#cp -p "$latest_file" /other/directory

