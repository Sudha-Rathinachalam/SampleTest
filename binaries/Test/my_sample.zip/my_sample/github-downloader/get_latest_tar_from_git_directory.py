
import re

git_file = "/var/lib/jenkins/github-downloader/git_log.txt"

match_rex = re.compile(r"(diff --git\s\w+\/binaries\/)(\w+.tar.gz)")
with open(git_file, "r+") as rgf:
    file_content = rgf.read()
    print(file_content)
    mo = re.search(match_rex, file_content)
    print(mo.groups())
    with open("/var/lib/jenkins/github-downloader/matched_tar_file.txt", "w+") as wgf:
        wgf.write(mo.group(2))
