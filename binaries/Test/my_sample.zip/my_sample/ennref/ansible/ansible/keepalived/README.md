Keepalived installation and configuration
==

1. Update the variables in fbcode/opseng/fava_ansible/keepalived/vars/keepalived_vars.yaml file.

2. Run the following Ansible command

    ansible-playbook -i inventory -l <site name> keepalived/keepalived.yaml 
