Dnsmasq
==

    cd ~/fbsource/fbcode/opseng/fava_ansible

    # Install and configure dnsmasq from the internet
    ansible-playbook -i inventory -l <site|host> dnsmasq/dnsmasq.yaml

    # Install and configure dnsmasq from an offline yum repo
    ansible-playbook -i inventory -l <site|host> dnsmasq/dnsmasq.yaml --extra-vars "yum_offline_repouri=<file_or_http_uri>"
