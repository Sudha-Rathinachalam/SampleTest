#!/usr/bin/env python3

import os
import sys
from subprocess import Popen, PIPE
import re
import inspect
import importlib
import click
import shutil
from datetime import datetime


def popen(cmd, cwd):
    p = Popen(cmd, stdout=PIPE, stderr=PIPE, cwd=cwd)

    out, err = p.communicate()
    if out is not None:
        out = out.decode()
    if err is not None:
        err = err.decode()
    ret = p.returncode

    print("'{}' command output:".format(' '.join(cmd)))
    print("return code: {}".format(ret))
    print("stdout: {}".format(out))
    print("stderr: {}".format(err))
    return (ret, out, err)


def gen_revision(alembic_root):
    rev_script = None

    ret, out, err = popen(["alembic", "revision", "--autogenerate"],
                          alembic_root)

    if ret:
        m = re.search("Target database is not up to date", out)
        if m is not None:
            ret = 0
    elif not ret:
        m = re.match(r"\s*Generating\s*([\/\w\.]+)", out)
        if m is not None:
            rev_script = m.groups()[0]
        else:
            print("Unable to get the migration python script")
            ret = 1

    return ret, rev_script


def del_not_applied_revision(alembic_root):
    # Backup the alembic versions dir since we might be deleting revisions
    ver_path = os.path.join(alembic_root, "migrations/versions")
    dest = f"{ver_path}_{datetime.now().strftime('%Y%m%d-%H%M%S')}~"
    shutil.copytree(ver_path, dest)

    rev_files = [f for f in os.listdir(ver_path)
                 if os.path.isfile(os.path.join(ver_path, f))
                 and f.endswith(".py")]
    print(f"Alembic revision filenames: {rev_files}")

    ret, out, err = popen(["alembic", "heads"], alembic_root)
    if ret:
        print("Unable to get alembic heads")
        return 1

    # This is a very rare case but it can happen.
    if len(re.findall(r"\(head\)", out)) > 1:
        print("Found multiple heads - Cannot proceed with alembic migration")
        return 1

    head_ver = None
    if "(head)" in out:
        head_ver = out.split(" ")[0]
        print(f"Alembic head version: {head_ver}")

    ret, out, err = popen(["alembic", "current"], alembic_root)
    if ret:
        print("Unable to get alembic current")
        return 1

    if head_ver in out:
        print("head version == current version. Something went wrong."
              "Debug this alembic issue manually")
        return 1

    for rev_file in rev_files:
        rev = rev_file.split('_')[0]
        if head_ver == rev:
            file_path = os.path.join(ver_path, rev_file)
            print(f"Deleting not applied revision: {file_path}")
            os.unlink(file_path)
            break

    return 0


@click.group(help="DB migration/schema update using alembic")
def cli():
    pass


@cli.command(help="Delete alembic revision script that was generated "
                  "but not applied to the db")
@click.option('--alembic-root', '-d', required=True,
              type=click.Path(exists=True),
              help='Path to alembic root directory')
def del_revision(alembic_root):
    ret = del_not_applied_revision(alembic_root)
    sys.exit(ret)


@cli.command(help="Check if DB migration/schema update is needed and "
                  "generates alembic DB revision script")
@click.option('--alembic-root', '-d', required=True,
              type=click.Path(exists=True),
              help='Path to alembic root directory')
def needs_update(alembic_root):
    ret, rev_script = gen_revision(alembic_root)
    if ret:
        print("Unable to generate alembic revision script")
        sys.exit(ret)
    elif not ret and rev_script is None:
        print("Found an old revision script that was not applied to the db")
        sys.exit(ret)

    print("Generated Alembic revision script: {}".format(rev_script))

    rev_script_dir = os.path.dirname(rev_script)
    rev_script_filename = os.path.splitext(os.path.basename(rev_script))[0]
    sys.path.insert(0, rev_script_dir)
    rev = importlib.import_module(rev_script_filename)

    upgrade_fn_src = inspect.getsource(rev.upgrade)
    if "pass\n" in upgrade_fn_src:
        print("Database up to date. No migration needed")
        os.unlink(rev_script)
    else:
        print("Database not up to date. Migration needed")


@cli.command(help="Execute the DB migration using alembic upgrade")
@click.option('--alembic-root', '-d', required=True,
              type=click.Path(exists=True),
              help='Path to alembic root directory')
def update(alembic_root):
    cmd = ["alembic", "upgrade", "head"]
    ret, out, err = popen(cmd, alembic_root)
    sys.exit(ret)


if __name__ == "__main__":
    cli()
