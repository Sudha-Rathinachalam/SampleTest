#!/usr/bin/env python3

import os
import sys


if len(sys.argv) < 2:
    print(f"Usage: {sys.argv[0]} <FAVA_version.txt_filepath>")
    sys.exit(1)

version_file = sys.argv[1]
# Use master by default
git_tag = "master"

if os.path.exists(version_file):
    with open(version_file) as f:
        for line in f:
            if "FAVA=" in line:
                version = line.strip('\n').split('=')[1]
                if "dev" != version:
                    git_tag = version
                break

print(git_tag)
sys.exit(0)
