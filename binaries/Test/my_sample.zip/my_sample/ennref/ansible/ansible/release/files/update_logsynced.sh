#!/bin/bash
# This update can take a while if task table has many entries
first_id=$(mysql -N -s -D fava -e 'select id from task where log_synced is NULL order by id limit 1')
while [ -n "$first_id" ]
do
        end=$((first_id+200000))
        if ! mysql -D fava -e  "UPDATE task SET log_synced=0 WHERE log_synced IS NULL and id < $end"
        then
                exit $?
        fi
        first_id=$(mysql -N -s -D fava -e 'select id from task where log_synced is NULL order by id limit 1')
done
