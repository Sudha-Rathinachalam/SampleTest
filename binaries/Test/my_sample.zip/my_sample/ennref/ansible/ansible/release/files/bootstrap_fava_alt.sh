#!/bin/bash

set -x

VENV_DIR=/workspace/venv/fava_alt
FAVA_ALT_CONTROLLER=controller-alt
FAVA_ALT_TASKAGENT_PORT=1090
FAVA_ALT_CONTROLLER_PORT=1092

function set_hostname() {
    hostname=$(hostname -s)
    if [ "$hostname" == "localhost" ]
    then
        rv=$(FAVA_CONTROLLER_HOST="$FAVA_ALT_CONTROLLER" FAVA_CONTROLLER_PORT="$FAVA_ALT_CONTROLLER_PORT" timeout 5s favacli.py show serial_number)
        rc=$?
        [ $rc -eq 0 ] && hostnamectl set-hostname "$rv"
    fi
}

function setup_fava_alt() {
    alt_override_fava=false
    cd /root || return
    wget -N http://$FAVA_ALT_CONTROLLER/etc/fava_alt_hosts_venv
    fn=fava_alt_hosts_venv
    if test -s "$fn" && grep -i "$(hostname)" $fn
    then
        check_install_venv
    else
        wget -N http://$FAVA_ALT_CONTROLLER/etc/fava_alt_hosts_override
        fn=fava_alt_hosts_override
        if test -s "$fn" && grep -i "$(hostname)" $fn
        then
            alt_override_fava_env
            alt_override_fava=true
        else
            return
        fi
    fi
    install_fava_alt_tests
    install_start_fava_alt "$alt_override_fava"
}

function check_install_venv() {
    if [ ! -e $VENV_DIR/bin/activate ]
      then
        python36 -m venv --system-site-packages $VENV_DIR || { echo "Error setting up py3env"; exit 1; }
    fi
    # shellcheck source=/dev/null
    source $VENV_DIR/bin/activate
}

function fava_alt_systemd_files() {
    cat > /etc/fava-alt.env << EOF
FAVA_LOG_FILE=/var/log/fava-alt.log
FAVA_CONTROLLER_HOST="$FAVA_ALT_CONTROLLER"
FAVA_TASKAGENT_PORT="$FAVA_ALT_TASKAGENT_PORT"
FAVA_CONTROLLER_PORT="$FAVA_ALT_CONTROLLER_PORT"
FAVA_TRACK_ADDR=False
FAVA_LOGROTATE_MAX_INTERVAL=600
LC_ALL=en_US.UTF8
PATH=/workspace/venv/fava_alt/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin
EOF

    cat << EOF > /etc/systemd/system/fava-alt.service
[Unit]
Description=FAVA taskagent
After=dhclient.service

[Service]
ExecStart=$VENV_DIR/bin/favacli.py service task-agent start
ExecStop=$VENV_DIR/bin/favacli.py service task-agent stop
Restart=always
EnvironmentFile=/etc/fava-alt.env

[Install]
WantedBy=multi-user.target
EOF
}

function install_start_fava_alt() {
    alt_override_fava="$1"
    python36 -m ensurepip --default-pip

    rm -rf ~/.cache/pip
    if [ -e $VENV_DIR/lib/python3.6/site-packages ]
    then
        rm -rf $VENV_DIR/lib/python3.6/site-packages/ProjectFava*
        rm -rf $VENV_DIR/lib/python3.6/site-packages/fava-*
        rm -rf $VENV_DIR/lib/python3.6/site-packages/fava
    fi

    pip install --trusted-host $FAVA_ALT_CONTROLLER --upgrade \
        -i http://$FAVA_ALT_CONTROLLER/pi_alt/simple wheel
    pip install --trusted-host $FAVA_ALT_CONTROLLER --pre --force-reinstall \
        -i http://$FAVA_ALT_CONTROLLER/pi_alt/simple fava

    if [ "$alt_override_fava" == "false" ]
    then
        fava_alt_systemd_files
        systemctl daemon-reload
        systemctl restart fava-alt
    else
        systemctl restart fava
    fi
}

function install_fava_alt_tests() {
    python36 -m ensurepip --default-pip

    rm -rf ~/.cache/pip
    if [ -e $VENV_DIR/lib/python3.6/site-packages ]
    then
        rm -rf $VENV_DIR/lib/python3.6/site-packages/fava_tests*
    fi

    pip install --trusted-host $FAVA_ALT_CONTROLLER --upgrade \
        -i http://$FAVA_ALT_CONTROLLER/pi_alt/simple wheel
    pip install --trusted-host $FAVA_ALT_CONTROLLER --pre --force-reinstall \
        -i http://$FAVA_ALT_CONTROLLER/pi_alt/simple fava_tests
}

function alt_override_fava_env() {
    # Used in place of a virtualenv installation, the fava alternate code
    # is run as the "primary" service on the node. This option is useful
    # when nodes are available exclusively for testing and aren't running
    # another FAVA service in parallel
    cd /root || return
    VENV_DIR=/root
    cat > /etc/fava.env << EOF
FAVA_LOG_FILE=/var/log/fava.log
FAVA_CONTROLLER_HOST=$FAVA_ALT_CONTROLLER
FAVA_TASKAGENT_PORT=$FAVA_ALT_TASKAGENT_PORT
FAVA_CONTROLLER_PORT=$FAVA_ALT_CONTROLLER_PORT
FAVA_TRACK_ADDR=False
LC_ALL=en_US.UTF8
EOF
}

set_hostname
setup_fava_alt

# EOF MARKER USED BY fava_utils.py DO NOT REMOVE
