Install/Upgrade FAVA
==

See the README.md in fbcode/opseng/fava_release for how to push a new FAVA package to a site.

Pushing only testsuites to FAVA sites
--

Install the following on your machine
--

1. python 3.6.x
2. pip3.6 install ansible
3. pip3.6 install click
4. pip3.6 install pyyaml

or

Follow instructions in <https://fb.quip.com/3KaYA7ALdJs6>

> **Replace \<ODM\> with the name of the ODM in the commands below**

To push testsuites to a FAVA stack by specifying the testsuite location(s) on the command line
--

    cd ~/fbsource/fbcode/opseng/fava_ansible

    ansible-playbook -i inventory -l <site> release/playbooks/testsuites_push.yaml -e "{'ts_path': ['~/fbsource/fbcode/fava/testsuites/common', '~/fbsource/fbcode/fava/testsuites/<ODM>']}"

To push testsuites to a FAVA stack by specifying the testsuites location(s) in the testsuite_mgmt_vars.yaml file
--

 Update ts_path variable in ~/fbsource/fbcode/opseng/fava_ansible/release/vars/testsuite_mgmt_vars.yaml and run the following commands

    cd ~/fbsource/fbcode/opseng/fava_ansible
    ansible-playbook -i inventory -l <site> release/playbooks/testsuites_push.yaml

Examples
--

    # To push to all FAVA L11 stacks at <ODM>
    cd ~/fbsource/fbcode/opseng/fava_ansible
    ansible-playbook -i inventory -l <ODM>_l11_primary release/playbooks/testsuites_push.yaml -e "{'ts_path': ['~/fbsource/fbcode/fava/testsuites/common', '~/fbsource/fbcode/fava/testsuites/<ODM>']}"


    # To push to one FAVA stack use one FAVA controller
    cd ~/fbsource/fbcode/opseng/fava_ansible
    ansible-playbook -i inventory -l snc01 release/playbooks/testsuites_push.yaml -e "{'ts_path': ['~/fbsource/fbcode/fava/testsuites/common', '~/fbsource/fbcode/fava/testsuites/<ODM>']}"

Supports shell pattern matching. See <https://www.gnu.org/software/findutils/manual/html_node/find_html/Shell-Pattern-Matching.html> for more details
--

    # Example: Push type 1 testsuites only
    cd ~/fbsource/fbcode/opseng/fava_ansible
    ansible-playbook -i inventory -l wmx01 release/playbooks/testsuites_push.yaml -e "{'ts_path': ['~/fbsource/fbcode/fava/testsuites/<ODM>/t1*']}"
