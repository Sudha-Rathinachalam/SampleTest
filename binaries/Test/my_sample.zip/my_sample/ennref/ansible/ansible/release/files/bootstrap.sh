#!/bin/bash

# This bootstrap script is executed as soon as the FAVA RAMFS mounts the
# /shared/fava filesystem.
#
# Its purpose is to:
# 1. Install the latest FAVA packages and tools
# 2. Configure alternate FAVA instances used by FAVA developers
#

LOG_FILE=/bootstrap_$(date +%y%m%d-%H%M%S).log
cd /root || return
wget -N http://controller/etc/bootstrap_internal.sh > >(tee -a "$LOG_FILE") 2>&1
/bin/bash ./bootstrap_internal.sh > >(tee -a "$LOG_FILE") 2>&1
