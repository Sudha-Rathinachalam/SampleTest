#!/usr/bin/env python3

import os
import sys
import logging
import shutil
import glob
from subprocess import Popen, PIPE
from collections import Counter
import click
import yaml


logger = logging.getLogger(__name__)


def config_logging():
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)

    logger.addHandler(ch)


config_logging()


class TestsuiteMgmt:
    def _popen(self, cmd, cwd):
        logger.debug(" ".join(cmd))
        p = Popen(cmd, stdout=PIPE, stderr=PIPE, cwd=cwd)
        o, e = p.communicate()

        if o is not None:
            o = o.decode()
        if e is not None:
            e = e.decode()

        return (o, e, p.returncode)

    def _get_ts_info(self, ts_path):
        ts_dir = os.path.dirname(ts_path)
        cmd = ["hg", "log", ts_path, "-l", "1", "--template",
               "{date(date,'%y%m%d')}_{node|short}"]

        (o, e, r) = self._popen(cmd, ts_dir)
        if r == 0 and len(o) > 0:
            return o
        else:
            logger.error(f"No commit info found for {ts_path}")
            return None

    def _is_valid_yaml_file(self, file_path):
        if file_path.endswith("yaml") or file_path.endswith("yml"):
            with open(file_path) as f:
                try:
                    if yaml.full_load(f) is None:
                        logger.error(f"yaml load failed for {file_path}")
                        return False
                except Exception as e:
                    logger.error(f"Error loading {file_path}: {e}")
                    return False
            return True
        else:
            logger.warning(f"Non yaml file {file_path} found")
            return False

    def _compile_ts_list(self, tspath):
        ts_path_list = []
        ts_filename_count = Counter()

        for path in tspath:
            if os.path.isdir(path):
                logger.debug(f"{path} is a dir")

                for root, _, files in os.walk(path):
                    for ts in files:
                        file_path = os.path.join(root, ts)

                        # skip non yaml file
                        if os.path.isfile(file_path) and \
                                self._is_valid_yaml_file(file_path):
                            ts_path_list.append(file_path)
                            ts_filename_count[ts.split('.')[0]] += 1
            else:
                if not self._is_valid_yaml_file(path):
                    # Fail for explicitly specified invalid testsuite file
                    logger.error(f"Invalid testsuite file: {path}")
                    return (None, None)

                ts_path_list.append(path)
                ts_filename_count[os.path.basename(path).split('.')[0]] += 1

        return (ts_path_list, ts_filename_count)

    def cp_ts_with_commit_info(self, ts_srcs, ts_dest_dir):
        ts_info = {}

        if not os.path.isdir(ts_dest_dir):
            logger.error(f"{ts_dest_dir} is not a directory")
            return 1

        # Support shell pattern matching for testsuite filenames and dirs
        tspath = set()

        for path in ts_srcs:
            glob_out = glob.glob(path)
            if not glob_out:
                logger.error(f"{path} does not exist")
                return 1
            # Filter duplicate testsuites path
            tspath.update(glob_out)

        # Compile a list of testsuites
        ts_path_list, ts_filename_count = self._compile_ts_list(tspath)
        if ts_path_list is None or ts_filename_count is None:
            logger.error("Failed to compile testsuites list")
            return 1

        # Fail if no testsuites are found in the path
        if len(ts_path_list) == 0:
            logger.error(f"No testsuites found in {tspath}")
            return 1

        # Check for duplicate testsuites
        for count in ts_filename_count.values():
            if count > 1:
                logger.error(f"Duplicate testsuites found in {tspath} - "
                             f"{ts_filename_count}")
                return 1

        # Find commit info of all testsuites
        for path in ts_path_list:
            ret = self._get_ts_info(path)
            if ret is None:
                logger.error(f"Failed to get commit info about "
                             f"testsuite: {path}")
                return 1
            ts_info[path] = ret
        logger.info(f"Testsuites commit info: {ts_info}")

        # Ensure the destination dir is empty
        if os.listdir(ts_dest_dir):
            logger.error(f"{ts_dest_dir} is not empty")
            return 1

        # Append the commit_info to the testsuite filenames.
        # Copy the testsuites to the destination dir.
        for src_file, commit_info in ts_info.items():
            ts_filename, ext = os.path.basename(src_file).split('.')
            dest_filename = f"{ts_filename}_{commit_info}.{ext}"
            dest_file = os.path.join(ts_dest_dir, dest_filename)
            shutil.copyfile(src_file, dest_file)

        return 0

    def add_testsuites(self, tsdir, overwrite):
        for dir in tsdir:
            for root, _, files in os.walk(dir):
                for ts in files:
                    if not ts.endswith(".yaml") and not ts.endswith(".yml"):
                        continue

                    ts_path = os.path.join(root, ts)
                    logger.info(f"Adding testsuite {ts}")
                    cmd = ["/usr/local/bin/favacli.py", "add", "testsuite",
                           ts_path]

                    if overwrite:
                        cmd.insert(-1, "--overwrite")

                    (o, e, r) = self._popen(cmd, os.getcwd())
                    if r != 0:
                        logger.error(f"Failed to add testsuite {ts}: "
                                     f"{o}, {e}")
                        return 1
        return 0


@click.group()
def cli():
    pass


@cli.command()
@click.option('--tspath', '-s', required=True, multiple=True,
              type=click.Path(),
              help='Path to testsuites file/directory')
@click.option('--ts-dest-dir', '-d', required=True,
              type=click.Path(exists=True),
              help='Path to dir to copy the testsuites with commit info '
                   'in the name')
def pkg_testsuites(tspath, ts_dest_dir):
    tm = TestsuiteMgmt()
    ret = tm.cp_ts_with_commit_info(tspath, ts_dest_dir)
    sys.exit(ret)


@cli.command()
@click.option('--tsdir', '-p', required=True, multiple=True,
              type=click.Path(exists=True),
              help='Path to testsuites directory')
@click.option('--overwrite/--no-overwrite', default=True,
              help='Overwrite testsuites if already exists')
def add_testsuites(tsdir, overwrite):
    tm = TestsuiteMgmt()
    ret = tm.add_testsuites(tsdir, overwrite)
    sys.exit(ret)


if __name__ == "__main__":
    cli()
