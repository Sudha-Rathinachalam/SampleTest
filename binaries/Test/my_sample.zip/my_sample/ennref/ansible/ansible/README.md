Collection of playbooks, scripts and configs used for collecting and configuring FAVA sites data
==

fava_inventory.yaml: The "master" hosts file, this file must be updated
whenever a site is added.

!Note that authentication to most hosts is expected to be preset using
your ssh keys or you will be prompted for passwords often!

Ansible with 2 factor authentication
------------------------------------

You have to jump through your devserver to ssh into the FAVA controllers in the lab.
Jumping through the devserver requires 2 factor auth(yubikey). So to avoid being
promoted for 2 factor auth passcode, create a ssh tunnel and tell Ansible to use it.

Create a SSH tunnel

    ssh -fNTL <local_port>:localhost:22 <fava_controller_host>

Add the following to the fava_inventory.yaml file

    <fava_controller_host>:
      ansible_host: localhost
      ansible_port: <local_port>
      ansible_user: root

Sample runs
-----------

FAVA versions
-------------

    ansible -i fava_inventory.yaml fava -m command -a "favacli.py --version" -f 20 -o

FAVA monthly report
-------------------

    ansible-playbook -i fava_inventory.yaml -l prime -e start="2019-02-01" -e end="2019-02-28" playbooks/fava_report.yaml

Display all racks actively in test
----------------------------------

    ansible-playbook -i fava_inventory.yaml -l prime playbooks/fava_active_racks.yaml

Decrypt Ansible vault file which has the FAVA credentials - Use default FAVA password
--

    ansible-vault view vault.yaml
