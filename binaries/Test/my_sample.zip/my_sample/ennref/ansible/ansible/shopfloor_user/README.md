Create a Linux user for the FAVA site leads to use
==

The create_user playbook create a new Linux user, configures sudo access for the new user and installs helper scripts to enable the site leads to do BOM import and mass recovery of FAVA jobs. To find out what permissions are granted to the new user, see ./files/sudoers_d_user.j2 sudoers file.

> The create_user.yaml playbook uses the encrypted vault.yaml file in fbsource/fbcode/opseng/fava_ansible which contains the Linux username and password. The command below will prompt for a password. Please enter our default FAVA password.

```bash
cd ~/fbsource/fbcode/opseng/fava_ansible

pip3.6 install -r requirements.txt

ansible-playbook -i inventory -l <site_name> shopfloor_user/create_user.yaml --vault-id @prompt

# Example
ansible-playbook -i inventory -l snc shopfloor_user/create_user.yaml --vault-id @prompt
```
