Chrony
==

    cd ~/fbsource/fbcode/opseng/fava_ansible

    # Update the following variables in dhcpd/vars/dhcpd_vars.yaml
    test_network_netmask: '<Example: 255.255.0.0>'
    test_network_start_subnet: '<Example: 10.0>

    # Install and configure chrony
    ansible-playbook -i inventory -l <site|host> dnsmasq/dnsmasq.yaml --extra-vars "yum_offline_repouri=<file_or_http_uri>"
