#!/bin/bash

# This script will enable Ansible logging which can be viewed in the ARA server link below.
# Source this script "source ara_enable.sh". Do not execute it.
# Source this script before upgrading a FAVA stack to enable Ansible logging for
# debugging and traceability.

# pip install -r requirements.txt - might require a sudo or use "--user" option

# Make sure python3 points to same python version
# which has ansible and ara installed
eval "$(python3 -m ara.setup.env)"

export ARA_API_CLIENT=http
export ARA_API_SERVER="http://snc3.fava.fb.com:8000"
export ARA_API_TIMEOUT=15
