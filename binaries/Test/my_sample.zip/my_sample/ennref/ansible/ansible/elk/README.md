#### Before running the elk playbooks to deploy ELK and beat packages

1. Verify the host(s) you are deploying ELK to has the children    elasticsearch_hosts, kibana_hosts
   and variable elasticsearch_host defined in the inventory file. Please see wmx.yaml in dir
   inventory for reference.

2. Customize the variables in elk/vars/elk_vars.yaml for the environment.

    a. To install ELK from a local/offline repo, set variable "elk_offline_repo_path" in elk/vars/elk_vars.yaml
       to the local repo url. For example file:///opt/es_pkgs or http://hostname/path

    b. To install ELK and beat (Metricbeat, packetbeat and filebeat) from the internet, remove or
       comment out variable "elk_offline_repo_path" in elk/vars/elk_vars.yaml

#### Example: To deploy ELK and beat packages to WMX ORT nodes, execute the following command
```
ansible-playbook -i inventory -l 'wmx_ort' elk/playbooks/elk_deploy.yaml --vault-id @prompt
```

#### Example: To remove ELK and beat packages from WMX ORT nodes, execute the following command
```
ansible-playbook -i inventory -l 'wmx_ort' elk/playbooks/elk_remove.yaml
```

#### Example: To get a list of hosts for a run, use the --list-hosts option
```
ansible-playbook --list-hosts -i inventory -l 'qmf_l10' elk/playbooks/elk_remove.yaml
```

