#!/usr/bin/env python36

import click
import csv
import json
import os
import time

from collections import OrderedDict
from pprint import pprint
from subprocess import Popen, PIPE


@click.group()
def cli():
    pass


@cli.command(help="Collect configuration snapshot")
def collect():
    config = {}

    cmds = OrderedDict()
    cmds["controller_os"] = "cat /etc/redhat-release"
    cmds["controller_kernel"] = "uname -r"
    cmds["fava_version"] = "favacli.py show version --fava_version"
    cmds["fava_tests_version"] = "favacli.py show version --tests_version"
    cmds["fava_install_date"] = "stat -c %z /usr/share/nginx/html/pi/fava-*.tar.gz"
    cmds["dhcpd_version"] = "dhcpd --version"
    cmds["ipv4_bootloader"] = (r'grep filename /etc/dhcp/dhcpd.conf '
                               r'| grep -v "#" | head -n1 | '
                               r'sed -e "s/filename \"\/\(.*\)\";/\\1/g"')
    cmds["ipv6_bootloader"] = (r'grep "bootfile-url \"" /etc/dhcp/dhcpd6.conf'
                               r' | grep -v "#" | head -n1 | '
                               r' sed "s/.*\/\(.*\)\";/\\1/g"')
    cmds["ramfs_controller_env"] = ("awk -F'=' '/^FAVA_DEFAULT_RAMFS/ "
                                    " {print $2}' /etc/fava-controller.env 2> "
                                    "/dev/null || echo ''")
    cmds["ramfs_wsgi_boot_env"] = ("awk -F'=' '/^FAVA_DEFAULT_RAMFS/ "
                                   "{print $2}' /etc/fava-wsgi.env "
                                   "2> /dev/null || echo ''")
    cmds["wsgi_boot_env"] = ("awk -F'=' '/EnvironmentFile/ {print $2}' "
                             "/etc/systemd/system/fava-wsgi-boot.service")
    cmds["mysql_version"] = (r'mysql --version | '
                             r'sed "s/mysql Ver \(.*\)for.*/\\1/g"')
    cmds["mysqlrouter_version"] = 'mysqlrouter --version | cut -d " " -f 3'
    cmds["mysql_fds"] = ("grep LimitNOFILE "
                         "/usr/lib/systemd/system/mysqld.service")
    cmds["mysqlrouter_fds"] = ("grep LimitNOFILE "
                               "/usr/lib/systemd/system/mysqlrouter.service")
    cmds["mysql_conn"] = "grep connect /etc/my.cnf"
    cmds["mysqlrouter_conf"] = ("grep -e connect -e ttl "
                                "/etc/mysqlrouter/mysqlrouter.conf")
    cmds["gluster_version"] = "glusterfs --version | head -n1"
    cmds["gluster_options"] = ("gluster vol info fava | sed -n '/Options/,$p'"
                               " | grep -v Options")
    cmds["kernel_options"] = "cat /etc/sysctl.conf | grep -v ^#",
    cmds["bootstrap_md5"] = "md5sum /opt/etc/bootstrap.sh | cut -d' ' -f1"
    cmds["bootstrap_site_md5"] = ("md5sum /opt/etc/bootstrap_site.sh | "
                                  "cut -d ' ' -f1")
    cmds["bootstrap_internal_md5"] = ("md5sum "
                                      "/opt/etc/bootstrap_internal.sh |"
                                      " cut -d' ' -f1")

    def run(opt, cmd):
        try:
            p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
            o, e = p.communicate()
            if opt == "dhcpd_version":
                rv = e.decode().strip()
            else:
                rv = o.decode().strip()
        except Exception:
            rv = ""
        return rv

    for opt, cmds in cmds.items():
        if not isinstance(cmds, tuple):
            cmds = (cmds,)
        for cmd in cmds:
            config[opt] = run(opt, cmd)

    print(json.dumps(config))


@cli.command(help="Convert configuration snapshots to CSV")
@click.argument('path')
@click.argument('outfile')
def tocsv(path, outfile):
    config = {}

    for site in os.listdir(path):
        with open(os.path.join(path, site)) as f:
            try:
                config[site] = json.load(f)
            except Exception:
                print("Error processing {}".format(site))

    for site, conf in config.items():
        print(site)
        pprint(conf)

    all_keys = set()
    for c in config.values():
        [all_keys.add(k) for k in c.keys()]

    sites = sorted(config.keys(), reverse=True)

    with open(os.path.join(outfile), "w") as f:
        writer = csv.writer(f, delimiter=str(','), quotechar=str('"'))
        writer.writerow([time.ctime()])
        writer.writerow(["module"] + [s.upper() for s in sites])
        for k in sorted(all_keys):
            writer.writerow([k] + [config[site].get(k, "") for site in sites])


if __name__ == '__main__':
    cli()
