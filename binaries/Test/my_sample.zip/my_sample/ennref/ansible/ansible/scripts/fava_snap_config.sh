#!/bin/bash

FDIR=/shared/fava

[ -d "$FDIR" ] || { echo "Invalid directory $FDIR"; exit 1; }

TARGET="$FDIR/snapshot_$(date +"%Y%m%d_%H%M%S")"

mkdir -p "$TARGET/priv"
mkdir -p "$TARGET/etc"
mkdir -p "$TARGET/etc/systemd/system"

cp "$FDIR/bootstrap.sh" "$TARGET/"

cp /root/dbcreds "$TARGET/priv/"
cp /root/ipmi_creds "$TARGET/priv/"
cp /etc/dutcreds "$TARGET/priv/"

cp /etc/systemd/system/fava* "$TARGET/etc/systemd/system"

rsync -a /etc/nginx "$TARGET/etc/"
rsync -a /etc/elasticsearch "$TARGET/etc/"
rsync -a /etc/glusterfs "$TARGET/etc/"
rsync -a /etc/dhcp "$TARGET/etc/"
rsync -a /etc/fava* "$TARGET/etc/"

rsync -a "$FDIR/bom" "$TARGET/"
rsync -a "$FDIR/assets" "$TARGET/"
rsync -a "$FDIR/scripts" "$TARGET/"
rsync -a "$FDIR/etc" "$TARGET/"
rsync -a "$FDIR/testsuites" "$TARGET/"

echo "$TARGET"
