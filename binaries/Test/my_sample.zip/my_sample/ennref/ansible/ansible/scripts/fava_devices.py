#!/usr/bin/env python36

import click
import os

try:
    from fava.lib.core import Fava
    from fava.data.model import Server
except Exception:
    # not all commands require FAVA to be imported
    pass


@click.group()
def cli():
    pass


@cli.command(help="collect number of devices tested per site")
def collect():
    fava = Fava()
    session = fava.db.get_session()
    print(session.query(Server.serial_number).count())


@cli.command(help="count number of devices tested")
@click.argument('path')
@click.option('-x', '--exclude', default=None, multiple=True,
              help="Exclude site/program")
def count(path, exclude):

    total = 0

    for r, _, files in os.walk(path):
        if exclude and os.path.basename(r) in exclude:
            continue
        for f in files:
            if f in exclude:
                continue
            p = os.path.join(r, f)
            try:
                with open(p) as handle:
                    total += int(handle.read())
            except Exception as e:
                print("Error processing {}: {}".format(p, e))

    print("Total devices: {}".format(total))


if __name__ == '__main__':
    cli()
