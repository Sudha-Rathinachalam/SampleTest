#!/usr/bin/env python

"""
Aggregate activity information collected using fava_activity.py
in a single Yaml report
"""

from __future__ import absolute_import, division, print_function, unicode_literals
import os
import sys
import yaml
import json

d = sys.argv[1] if len(sys.argv) > 1 else "./activity"
git_f = sys.argv[2] if len(sys.argv) > 2 else "activity.yaml"

data = {}
for f in os.listdir(d):
    p = os.path.join(d, f)
    try:
        # a bit of a hack to remove any non-JSON data
        # this comes up for example for SSH messages
        # emitted by Ansible
        lines = [l for l in open(p).readlines()
                 if l.startswith('{')]
        rv = json.loads("\n".join(lines))
        data[f.split(".", 1)[1]] = rv
    except Exception as e:
        print("Error processing {} {}".format(p, e))


rv = yaml.safe_dump(data, default_flow_style=False)
print(rv)
with open(os.path.join(d, git_f), "w") as f:
    f.write(rv)
