#!/bin/env python36

"""
Returns all TLAs ingested at a site
"""

from __future__ import absolute_import, division, print_function
from __future__ import unicode_literals

from fava.lib.core import Fava
from fava.data.model import Configuration

fava = Fava()

with fava.db.session_scope() as session:
    rv = session.query(Configuration.fb_part_number,
                       Configuration.hw_config['build_id']).filter(
        Configuration.fb_part_number.like("15-%")).all()

    for c in rv:
        fbpn = c[0]
        build_id = c[1] or ""
        print("{}\t{}".format(fbpn, build_id))
