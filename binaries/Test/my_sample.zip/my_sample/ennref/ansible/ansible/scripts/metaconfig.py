#!/bin/env python

import csv
import json
import os
import sys
import time

from pprint import pprint

if len(sys.argv) < 2:
    sys.stderr.write("Path to config directory is required.\n")
    sys.exit(1)

confdir = sys.argv[1]
config = {}

for site in os.listdir(confdir):
    with open(os.path.join(confdir, site)) as f:
        try:
            config[site] = json.load(f)
        except Exception:
            print("Error processing {}".format(site))

for site, conf in config.items():
    print(site)
    pprint(conf)


all_keys = set()
for c in config.values():
    [all_keys.add(k) for k in c.keys()]

sites = sorted(config.keys(), reverse=True)

with open(os.path.join("metaconfig.csv"), "wb") as f:
    writer = csv.writer(f, delimiter=str(','), quotechar=str('"'))
    writer.writerow([time.ctime()])
    writer.writerow(["module"] + [s.upper() for s in sites])
    for k in sorted(all_keys):
        writer.writerow([k] + [config[site].get(k, "") for site in sites])
