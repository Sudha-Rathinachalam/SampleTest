#!/bin/env python36

"""
Fix inconsitencies in DB's Task records, including:

  * Tasks with no end time that are associated to a finished Job
  * Finished tasks missing a result
  * Tasks that aren't associated to a job
  * Scanned out racks that have unfinished jobs

"""

import sys
import logging

from fava.lib.core import Fava
from fava.data.model import Server, Job, Task


log_level = int(sys.argv[2]) if len(sys.argv) > 3 else 20
logging.basicConfig(level=log_level)

fava = Fava()
pretend = False
m = "[pretend]" if pretend else ""
start_times = []


def fix_tasks_state():
    with fava.db.session_scope() as session:
        q = session.query(Task, Job)
        q = q.filter(Task.job_id == Job.id)
        q = q.filter(~Job.end.is_(None), ~Task.data["background"],
                     Task.end.is_(None))
        for task, job in q.all():
            start_times.append(task.start)
            logging.debug("{} reconciling task end time of {} "
                          "{} {}".format(m, task.id, task.name, task.start))
            if not pretend:
                if task.result is None:
                    task.result = 1
                task.end = job.end
                session.merge(task)

        sst = sorted(start_times)
        earliest = sst[0] if sst else "N/A"
        latest = sst[-1] if sst else "N/A"

        logging.info("{} fixing {} tasks started "
                     "[{}, {}]".format(m, q.count(), earliest, latest))

        miss_results = session.query(Task).filter(~Task.end.is_(None),
                                                  Task.result.is_(None)).all()
        logging.info("Finished tasks missing a result {}".format(
                     len(miss_results)))
        if not pretend:
            for t in miss_results:
                t.result = 1
                session.merge(t)

        orphaned_tasks = session.query(Task).filter(
            Task.job_id.is_(None)).all()
        if not pretend:
            [session.delete(ot) for ot in orphaned_tasks]
        logging.info("Orphaned tasks {}".format(len(orphaned_tasks)))

        jobs = session.query(Job).filter(Job.end.is_(None),
                                         Job.servers.any(
                                             Server.state == 'scanout')).all()
        logging.info("{} fixing {} unfinished jobs on scanned "
                     "out assets".format(m, len(jobs)))
        logging.debug("Jobs {}".format([j.id for j in jobs]))
        if not pretend:
            [fava.kill_job(j.id, force=True) for j in jobs]


fix_tasks_state()
