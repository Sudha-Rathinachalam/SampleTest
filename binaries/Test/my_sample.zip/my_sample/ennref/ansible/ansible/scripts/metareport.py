#!/usr/bin/env python

"""
Summarize site reports into a csv "meta" report
aggregated over

jobs_run
jobs_passed
jobs_failed
tasks_run
tasks_passed
tasks_failed
servers_tested
racks_scanned_out
racks_tested"

see fava_report.py for details
"""

from __future__ import absolute_import, division, print_function, unicode_literals
import json
import sys
import os
import csv

from collections import OrderedDict

dest = os.path.abspath(sys.argv[1]) if sys.argv else "."

sites = {}
for root, _, files in os.walk(dest):
    for f in files:
        if f.startswith("report."):
            print(os.path.join(root, f))
            with open(os.path.join(root, f)) as r:
                try:
                    sites[f.split(".", 1)[1]] = json.load(r)
                except Exception:
                    print("Error processing file {}".format(f))

sites = OrderedDict(sorted(sites.items()))

site_keys = sites.values()[0].keys()

short_keys = ["jobs_run", "jobs_passed", "jobs_failed", "tasks_run",
              "tasks_passed", "tasks_failed", "servers_tested",
              "racks_scanned_out", "racks_tested"]

long_keys = ["fail_codes", "jobs_suites", "tla", "tla_conf"]
if any(s not in site_keys for s in short_keys + long_keys):
    raise Exception("Fields mismatch")

for s in sites:
    for k in long_keys:
        if isinstance(sites[s][k], dict):
            sites[s][k] = OrderedDict(sorted(sites[s][k].items(), key=lambda v: v[1],
                                             reverse=True))


with open(os.path.join(dest, "metareport.csv"), "wb") as f:
    writer = csv.writer(f, delimiter=str(','), quotechar=str('"'))
    writer.writerow(["site"] + short_keys)
    for site, values in sites.items():
        if site in ("qmn02", "qmn12", "qmn13", "qmn03"):
            continue
        writer.writerow([site] + [values[k] for k in short_keys])

    writer.writerow(["site"] + long_keys)
    for site, values in sites.items():
        if site in ("qmn02", "qmn12", "qmn13", "qmn03"):
            continue
        val = []
        for k in long_keys:
            if isinstance(values[k], dict):
                _v = ""
                for vk, vv in values[k].items():
                    _v += "{}:{}\n".format(vk, vv)
                val.append(_v)
            else:
                val.append(str(values[k]))
        writer.writerow([site] + val)
