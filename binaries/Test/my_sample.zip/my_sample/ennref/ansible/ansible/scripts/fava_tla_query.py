#!/bin/env python36

"""
Returns whether a given TLA FBPN has been tested
"""

from __future__ import absolute_import, division, print_function, unicode_literals
import sys

from fava.lib.core import Fava
from fava.data.model import Configuration

fava = Fava()

if len(sys.argv) < 2:
    print("TLA argument is required")
    sys.exit(1)

with fava.db.session_scope() as session:
    print(session.query(Configuration).filter(
        Configuration.fb_part_number == sys.argv[1].strip()).count() > 0)
