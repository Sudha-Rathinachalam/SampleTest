#!/bin/sh

set -x

backdir=/root/backup/Fava-$(date +%y%m%d-%H%M%S)
mkdir -p "$backdir"
mv /root/ProjectFava-0.2 "$backdir"
mv /root/fava-0.2 "$backdir"
mv /root/fava_tests-0.2 "$backdir"

install_fava() {
    cp /shared/fava/pkgs/fava-0.2.tar.gz /root
    cd /root || exit
    rm -rf ProjectFava-0.2
    rm -rf fava-0.2
    rm -rf /usr/local/lib/python3.6/site-packages/fava
    pip uninstall -y ProjectFava
    pip uninstall -y fava
    rm -rf /usr/local/lib/python3.6/site-packages/ProjectFava-0.2_*
    tar xzf fava-0.2.tar.gz
    cd fava-0.2 || exit
    python36 setup.py install --force
}

install_fava_tests() {
    cp /shared/fava/pkgs/fava_tests-0.2.tar.gz /root
    cd /root || exit
    rm -rf fava_tests-0.2
    rm -rf /usr/local/lib/python3.6/site-packages/fava_tests
    pip uninstall -y fava_tests
    tar xzf fava_tests-0.2.tar.gz
    cd fava_tests-0.2 || exit
    python36 setup.py install --force
}

ip=$(grep -o "10\..\.0\.1*" /usr/local/bin/fava_service_status.py)
install_fava
install_fava_tests
sed -i "s/10.0.0.1/$ip/" /usr/local/bin/fava_service_status.py
services="fava-controller fava fava-dhcp fava-dhcp6 fava-wsgi fava-wsgi-boot"
for s in $services; do
  systemctl restart "$s"
  systemctl status "$s"
done

/usr/local/bin/fava_service_status.py > /tmp/fava_service_status.py.log 2>&1
