#!/bin/env python36

"""
Collect configuration and activity information

Returns a dictionary formatted as JSON that includes

in_test: List of racks or servers currently testing
task_errors: id and name of tasks that failed
maybe_stuck: running tasks that are beyond expected runtime
version: fava version

"""

from __future__ import absolute_import, division, print_function, unicode_literals
import json

from datetime import datetime, timedelta
from collections import Counter
from subprocess import check_output

from fava.lib.core import Fava
from fava.data.model import Configuration, Rack, Server, Job, Task


class TaskDuration(dict):

    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)

    def get(self, key, default=3600):
        d = default
        if key == "StressappTest":
            d = 3600 * 13
        elif key == "PtugenTest":
            d = 3600 * 5
        elif key == "MprimeTest":
            d = 3600 * 6
        elif key == "PTUMon":
            d = 3600 * 6
        return timedelta(seconds=d)


fava = Fava()

version = str(check_output(["favacli.py", "--version"]).strip())
now = datetime.now()
dur_map = TaskDuration()


rv = {"in_test": {}, "task_errors": [], "maybe_stuck": [], "version": version}

with fava.db.session_scope() as session:
    q = session.query(Rack.fb_part_number,
                      Configuration.hw_config["product_line"],
                      Configuration.hw_config["product_type"])
    q = q.filter(Configuration.fb_part_number == Rack.fb_part_number)
    racks = q.filter(~Rack.state.in_(["scanout", "rack_scanout"])).all()
    for k, v in Counter(racks).items():
        rv["in_test"][" ".join(k)] = v

    q = session.query(Job.id, Task)
    q = q.filter(Task.job_id == Job.id)
    q = q.filter(Job.state == "started", Task.state != "running",
                 Task.result != 0)
    failed_tasks = q.all()

    if failed_tasks:
        rv["task_errors"] = ["{}: {} - {}".format(t.id, str(t.name), str(t.end))
                             for _, t in failed_tasks]

    # Query server level test environments
    if not rv["in_test"] and rv["task_errors"]:
        q = session.query(Server.fb_part_number,
                          Configuration.hw_config["product_line"],
                          Configuration.hw_config["product_type"])
        q = q.filter(Configuration.fb_part_number == Server.fb_part_number)
        servers = q.filter(~Server.state.in_(["scanout"])).all()
        for k, v in Counter(servers).items():
            s = [i for i in k if i]
            rv["in_test"][" ".join(s)] = v

    q = session.query(Task)
    q = q.filter(Task.end.is_(None), Task.result.is_(None),
                 ~Task.data["background"])
    stuck = [t for t in q.all() if (t.start < now - dur_map.get(t.name))]
    if stuck:
        rv["maybe_stuck"].extend([(t.id, t.name) for t in stuck])


print(json.dumps(rv).strip("\r\n"))
