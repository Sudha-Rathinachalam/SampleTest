#!/usr/bin/env python36

import csv
import click
import hashlib
import json
import os
import re
import time

from collections import OrderedDict, defaultdict
from datetime import datetime, timedelta
from subprocess import check_output

try:
    from fava.data.model import Job
    from fava.lib.core import Fava
except Exception:
    # not all commands require FAVA, Ok to miss
    pass


@click.group()
@click.pass_context
def cli(ctx):
    pass


@cli.command()
@click.argument('path')
@click.argument('output')
def tocsv(path, output):
    config = {}

    for site in os.listdir(path):
        with open(os.path.join(path, site)) as f:
            try:
                config[site] = json.load(f)
            except Exception:
                print("Error processing {}".format(site))

    sites = sorted(config.keys(), reverse=True)
    ml = 0
    for s in sites:
        ml = max(ml, len(config[s]))

    with open(output, "w") as f:
        writer = csv.writer(f, delimiter=str(','), quotechar=str('"'))
        writer.writerow([time.ctime()])
        r = []
        for s in sites:
            r.append(s)
            r.append("")
        writer.writerow(r)
        r = []
        for _ in sites:
            r.append("Name")
            r.append("Checksum")
        writer.writerow(r)

        for i in range(ml):
            r = []
            for site in sites:
                if len(config[site]) > i:
                    r.extend(config[site][i][0:2])
                else:
                    r.extend(["", ""])
            writer.writerow(r)


@cli.command()
@click.argument('path')
@click.argument('output')
def source(path, output):
    for f in os.listdir(path):
        with open(os.path.join(path, f)) as rh:
            try:
                suites = json.load(rh)
                if not os.path.isdir(os.path.join(output, f)):
                    os.mkdir(os.path.join(output, f))
                for suite in suites:
                    with open(os.path.join(output, f, suite[0]), "w") as wh:
                        wh.write(suite[2])
            except Exception as e:
                print("Failed to process {}: {}".format(f, e))


@cli.command()
@click.argument('path')
def countcases(path):
    counts = defaultdict(list)
    keys = ["fat", "pretest", "runin", "fst", "nettest", "shiptest"]
    for key in keys:
        for r, _, files in os.walk(path):
            for f in files:
                if key in f:
                    o = check_output(["grep", "-i", "name",
                                     os.path.join(r, f)])
                    counts[key].append(len(o.decode().split("\n")))
    for k, v in counts.items():
        if v:
            print("{}: min {} mean {} median {} max {}".format(k, min(v),
                  sum(v) / len(v), sorted(v)[int(len(v) / 2)], max(v)))


@cli.command()
def collect():
    fava = Fava()

    interval = datetime.now() - timedelta(days=60)

    with fava.db.session_scope() as session:
        jobs = session.query(Job).filter(
            Job.start >= interval).all()

        suites = OrderedDict()
        for j in jobs:
            d = j.data['testsuite']
            s = j.data.get('source')
            h = hashlib.md5(s.encode()).hexdigest() if s else None
            m = re.match("(?P<name>.*)_v(?P<id>[0-9]+)$", d)
            if m:
                n = m.group("name")
                v = int(m.group("id"))
                if n not in suites or (suites[n][0] and int(suites[n][0]) < v):
                    suites[m.group("name")] = (m.group("id"), h, s)
            else:
                suites[d] = (None, h, s)

        res = []
        for k, val in sorted(suites.items(), key=lambda x: x[0]):
            num = val[0]
            v = val[1]
            s = val[2]
            if num:
                k = k + "_v" + num
            res.append([k, v, s])
        print(json.dumps(res))


if __name__ == '__main__':
    cli(obj={})
