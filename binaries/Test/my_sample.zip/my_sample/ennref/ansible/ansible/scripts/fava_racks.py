#!/bin/env python36

"""
Returns a comma-separated list of rack identifiers tested
"""

from __future__ import absolute_import, division, print_function, unicode_literals
from fava.lib.core import Fava
from fava.data.model import Rack

fava = Fava()
session = fava.db.get_session()
racks = [r[0] for r in session.query(Rack.serial_number).all()]
print(",".join(racks))
