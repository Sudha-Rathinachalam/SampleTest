#!/bin/env python36

"""
Summary report of activity over a given period of time, including

racks_scanned_out: number of racks scanned out
jobs_run:       Number of jobs run
jobs_passed:    Number of jobs that passed
jobs_failed:    Number of jobs that failed
jobs_suites:    Name of test suites run
tasks_run:      Number of tasks run
tasks_passed:   Number of tasks that passed
tasks_failed:   Number of tasks that failed
fail_codes:     Counter of error codes
racks_tested:   Number of racks tested (may differ from scanned out)
servers_tested: Number of servers tested
tla:            Top-Level FBPN
tla_conf:       Description of FBPN by type and model

"""

from __future__ import absolute_import, division, print_function, unicode_literals
import json
import logging

from fava.lib.core import Fava
from fava.data.model import Job, Task, Rack, Server, Event, Configuration

logging.basicConfig(level=logging.INFO)

fava = Fava()

start = "{{ t_start }}"
end = "{{ t_end }}"

report = {}

with fava.db.session_scope() as session:
    logging.info("Racks scanned out")
    racks_scanned_out = session.query(Event).filter(
        Event.time > start,
        Event.time < end,
        Event.type == 'rack_scanout').count()

    logging.info("Jobs")
    q = session.query(Job).filter(Job.start >= start, Job.start <= end)
    servers = set()
    racks = set()
    testsuites = {}
    for job in q.all():
        testsuites.setdefault(job.data["testsuite"], 0)
        testsuites[job.data["testsuite"]] += 1
        for s in job.servers:
            servers.add(s.serial_number)
            racks.add(s.rack)

    logging.info("Rack TLA")
    fbpn = session.query(Rack.fb_part_number).filter(
        Rack.serial_number.in_(racks)).all()
    tla = {}
    for pn in fbpn:
        tla.setdefault(pn[0], 0)
        tla[pn[0]] += 1

    logging.info("Server TLA")
    fbpn = session.query(Server.fb_part_number).filter(
        Server.serial_number.in_(servers)).all()
    for pn in fbpn:
        tla.setdefault(pn[0], 0)
        tla[pn[0]] += 1

    logging.info("Configs")
    configs = session.query(Configuration).filter(
        Configuration.fb_part_number.in_(tla.keys())).all()
    tla_conf = {}
    for c in configs:
        conf = "{} {}".format(c.hw_config.get("product_type"),
                              c.hw_config.get("product_line"))
        tla_conf[c.fb_part_number] = conf

    jobs_run = q.count()
    jobs_pass = q.filter(Job.result == 0).count()
    jobs_fail = q.filter(Job.result != 0).count()

    logging.info("Tasks")
    q = session.query(Task).filter(Task.start >= start, Task.end <= end)
    tasks_run = q.count()
    tasks_pass = q.filter(Task.result == 0).count()
    tasks_fail = q.filter(Task.result != 0).count()

    all_tasks = q.all()
    tasks_code = {}
    for task in all_tasks:
        if task.result != 0 and task.code:
            tasks_code.setdefault(task.code, 0)
            tasks_code[task.code] += 1

    report["racks_scanned_out"] = racks_scanned_out
    report["jobs_run"] = jobs_run
    report["jobs_passed"] = jobs_pass
    report["jobs_failed"] = jobs_fail
    report["jobs_suites"] = testsuites
    report["tasks_run"] = tasks_run
    report["tasks_passed"] = tasks_pass
    report["tasks_failed"] = tasks_fail
    report["fail_codes"] = tasks_code
    report["racks_tested"] = len(racks)
    report["servers_tested"] = len(servers)
    report["tla"] = tla
    report["tla_conf"] = tla_conf

    print(json.dumps(report))
