#!/usr/bin/env python36

"""
Convert inventory to .ssh_config format

Example run:

ansible-inventory -i inventory --list | \
   python36 ./scripts/inventory_to_ssh_config.py > fava_ssh_config

To use, either point ssh to the custom file, e.g.
   ssh -F fava_ssh_config <host>

Or copy the file to ~/.ssh/config.d and use the Include directive
in ~/.ssh/config to add it, e.g.

Include config.d/fava_ssh_config
"""

import sys
import json

from collections import defaultdict


f = sys.stdin.read()

d = json.loads(f)
hosts = d["_meta"]["hostvars"]

ssh_conf = []

fwd_m_prefix = defaultdict(lambda: 0)
fwd_m_suffix = defaultdict(lambda: 42)
fwd_g_prefix = 1


def fwd_port(host):
    """
    Return a unique port for a host.
    The port is of the form "{prefix}4{suffix}"
    where prefix is derived from the first 3 letters of a host
    and suffix is uniquely incremented for each prefix
    For example
    odm11
    vendor01
    odm12
    vendor02

    the prefix will be based on 'odm' and 'ven' leading to
    odm11    --> 2443
    odm12    --> 2444
    vendor01 --> 3443
    vendor02 --> 3444
    """

    global fwd_g_prefix

    n = h[:3]
    # construct a unique local forwarding port for this host
    if n not in fwd_m_prefix:
        fwd_g_prefix += 1
        fwd_m_prefix[n] += fwd_g_prefix
    # and assigning a unique suffix
    fwd_m_suffix[n] += 1

    port = "{}{}{}".format(fwd_m_prefix[n], 4, fwd_m_suffix[n])

    return port


for h in sorted(hosts):
    host = hosts[h]
    port = fwd_port(h)
    localport = None

    addr = host.get("ansible_host") or host.get("ansible_host6")
    if addr == "localhost" and host.get("ansible_port"):
        localport = host["ansible_port"]
    user = host.get("ansible_user", "root")
    ssh_conf.append("Host {}".format(h))
    ssh_conf.append("  User {}".format(user))
    ssh_conf.append("  ForwardAgent yes")
    if (host.get("ansible_ssh_common_args")
            and "Proxy" in host["ansible_ssh_common_args"]):
        ssh_conf.append("  Hostname {}".format(addr))
        proxy = host["ansible_ssh_common_args"].split(" ")[-1]\
                                               .replace('"', '')\
                                               .strip()
        ssh_conf.append("  ProxyJump {}".format(proxy))
    elif addr:
        ssh_conf.append("  Hostname {}".format(addr))
    if localport:
        ssh_conf.append("  Port {}".format(localport))
    ssh_conf.append("  LocalForward {} localhost:443".format(port))
    ssh_conf.append("")


print("\n".join(ssh_conf))
