Gluster Ansible playbooks
==

Ensure that /etc/hosts on all hosts has two entries for each host: one for the production IP and one for the MySQL IP.

    cd ~/fbsource/fbcode/opseng/fava_ansible

Ensure all variables in ./gluster/vars/gluster_vars.yaml are correct for the environment.
Particularly yum_offline_repouri. Do not use gluster mount location /shared/fava
to store the Gluster yum_cache since we are installing Gluster using this playbook.

Setup Gluster offlline yum cache
--

    # Install git-lfs
    git clone https://github.com/facebookexternal/fava.git
    # Copy centos-gluster5 yum cache to all nodes in the FAVA stack
    scp -r fava/fava_bundle/yum_cache/centos-gluster5 <controller>:/opt

To completely remove Gluster - Will not remove the data in the brick
--

    ansible-playbook -i inventory -l <site|host> gluster/gluster_complete_rm.yaml

To install and configure gluster in a 3 node or one node setup
--

A single node cluster will be created on controller1 if the -l option
in the ansible-playbook command below points to less than 3 nodes

A 3 node replicated cluster will be created using 3 nodes(controller1,
controller2, controller3) if the -l option in the ansible-playbook command
below points to 3 or more nodes.

    ansible-playbook -i inventory -l <site|host> gluster/gluster.yaml
