#!/bin/bash

if [ "$#" -lt 1 ]
then
    echo "Current Gluster brick location is needed"
    exit 1
fi

brick_path_list=("$@")

for vol in $(gluster volume list)
do
    echo 'y' | gluster volume stop "$vol"
    echo 'y' | gluster volume delete "$vol"
done

systemctl stop glusterd glusterfsd
killall -9 glusterfs glusterfsd glusterd

yum remove -y glusterfs* glusterd
rm -rf /var/log/glusterfs
rm -rf /var/lib/glusterd

# Remove the gluster metadata from tbe bricks
for brick_path in "${brick_path_list[@]}"
do
    rm -rf "$brick_path"/.glusterfs
done