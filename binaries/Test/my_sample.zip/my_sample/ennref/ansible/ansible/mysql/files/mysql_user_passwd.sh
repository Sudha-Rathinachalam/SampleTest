#!/bin/bash

exec 2>&1
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <dbpass> <dbport>"
    exit 1
fi

dbpass="$1"
port="$2"

# Check if the default password was changed before?
echo "Checking if the default MySQL password has already been changed"
if ! mysql -p"$dbpass" --protocol=TCP -h localhost -u root -P "$port" --connect-expired-password -e "SHOW DATABASES"
then
    echo "Changing default MySQL password"
    # Change default password
    MPASS=$(tac /var/log/mysqld.log | grep "temporary password" | head -n1 | sed -e "s/.*root@localhost: //")
    mysql -p"$MPASS" --protocol=TCP -h localhost -u root -P "$port" --connect-expired-password -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$dbpass'"
fi

set -e
echo "Creating MySQL user root@%"
mysql -p"$dbpass" --protocol=TCP -h localhost -u root -P "$port" --connect-expired-password -e "CREATE USER IF NOT EXISTS 'root'@'%' IDENTIFIED BY '$dbpass'"
echo "Granting privileges to MySQL user root@%"
mysql -p"$dbpass" --protocol=TCP -h localhost -u root -P "$port" --connect-expired-password -e "GRANT ALL PRIVILEGES on *.* to 'root'@'%';"
mysql -p"$dbpass" --protocol=TCP -h localhost -u root -P "$port" --connect-expired-password -e "GRANT GRANT OPTION on *.* to 'root'@'%';"
