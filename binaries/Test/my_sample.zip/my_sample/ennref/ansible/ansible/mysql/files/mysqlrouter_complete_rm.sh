#!/bin/bash

exec 2>&1
set -x

systemctl stop fava-controller fava fava-dhcp fava-dhcp6 fava-wsgi fava-wsgi-boot mysqlrouter

yum remove -y mysql-router*

rm -rf /var/lib/mysqlrouter
rm -rf /var/log/mysqlrouter
rm -rf /etc/mysqlrouter
