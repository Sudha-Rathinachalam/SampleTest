# MySQL installation, configuration and Innodb creation playbooks and files

> The MySQL playbooks works with MySQL 8.x+ only

## Before running the complete remove playbooks

Update the datadir in mysql_vars.yaml if required.

## Completely remove MySQL and mysqlrouter

This playbook will backup the FAVA DB but do a manual backup to be extra safe.

    ansible-playbook -i inventory -l <host> mysql/playbooks/mysql_complete_rm.yaml --vault-id @prompt

## Completely remove mysqlrouter only

    ansible-playbook -i inventory -l <host> mysql/playbooks/mysqlrouter_complete_rm.yaml

## Completely remove MySQL daemon only

This playbook will backup the FAVA DB but do a manual backup to be extra safe.

    ansible-playbook -i inventory -l <host> mysql/playbooks/mysqld_complete_rm.yaml --vault-id @prompt

## Create a single node standalone MySQL server

1. Update the variables in mysql_vars.yaml file.

    a. Reduce the innodb_buffer_pool_size if required.

2. Install and configure standalone MySQL

        ansible-playbook -i inventory -l <host> mysql/playbooks/mysql_install.yaml --vault-id @prompt

## Create a MySQL innodb cluster, install and configure mysqlrouter on all nodes

1. Ensure the following variables are defined. Ideally in the inventory file for every fava controller cluster.

        mysql_master: snc3

        mysql_slave1: snc1

        mysql_slave2: snc2 [optional var - create 2 node cluster]

2. Update the variables in mysql_vars.yaml file.

3. To install MySQL, create a Innodb cluster and install mysqlrouter

        ansible-playbook -i inventory -l <fava_site_name> mysql/site.yaml --vault-id @prompt
        # Example
        ansible-playbook -i inventory -l snc mysql/site.yaml --vault-id @prompt

4. For granular control, run the following Ansible commands instead of step 3

        # Install and configure standalone MySQL
        ansible-playbook -i inventory -l <fava_site_name> mysql/playbooks/mysql_install.yaml --vault-id @prompt

        # Create Innodb cluster
        ansible-playbook -i inventory -l <fava_site_name> mysql/playbooks/mysql_create_innodb_cluster.yaml --vault-id @prompt

        # Install and configure mysqlrouter
        ansible-playbook -i inventory -l <fava_site_name> mysql/playbooks/mysqlrouter_install.yaml --vault-id @prompt
