#!/usr/bin/env python36

import sys
from subprocess import Popen, PIPE
from argparse import ArgumentParser


def mysql_cluster(db_passwd, db_port, num_nodes_in_cluster):
    try:
        db_uri = "root@localhost:{}".format(db_port)

        cmd = ["mysqlsh", "--py", "--uri={}".format(db_uri),
               "--ssl-mode=DISABLED",
               "-p{}".format(db_passwd), "-e", 'print(dba.get_cluster()'
               '.status()["defaultReplicaSet"]["status"])'
               ]

        p = Popen(cmd, stdout=PIPE, stderr=PIPE)
        (o, _) = p.communicate()
        o = o.decode()
        print(f"cluster.status() output: {o}")

        cluster_status = "OK"
        if num_nodes_in_cluster < 3:
            cluster_status = "OK_NO_TOLERANCE"

        status = False
        for line in o.splitlines():
            if line.strip() == cluster_status:
                print(f"Cluster status: {cluster_status}")
                status = True
                break

        return status
    except Exception:
        return False


if __name__ == "__main__":
    parser = ArgumentParser(description="MySQL innodb cluster status")
    parser.add_argument("db_passwd")
    parser.add_argument("db_port", type=int)
    parser.add_argument("num_nodes_in_cluster", type=int)
    args = parser.parse_args()

    if mysql_cluster(args.db_passwd, args.db_port, args.num_nodes_in_cluster):
        sys.exit(0)
    else:
        sys.exit(1)
