#!/bin/bash

exec 2>&1
if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <dbpass> <mysqld_port_standalone> <mysqld_port_innodb_cluster>"
    echo "$0 will try backing up fava DB using the standalone port first, on failure it will try the innodb cluster mysqld port"
    exit 1
fi

db_pass="$1"
db_port1="$2"
db_port2="$3"

function db_backup() {
    db_port=$1
    echo "Trying to backup fava DB using port $db_port"
    if mysql -p"$db_pass" -h localhost --protocol=TCP -P "$db_port" -e "SHOW DATABASES" | grep fava
    then
        echo "Backing up MySQL fava db without gtid"
        mysqldump -p"$db_pass" -h localhost --protocol=TCP -P "$db_port" --databases fava --single-transaction --triggers --routines --events --set-gtid-purged=OFF > /shared/fava/mysql-fava-no-gtid."$(date +%g%m%d-%H:%M:%S)".sql

        echo "Backing up MySQL fava db with gtid"
        mysqldump -p"$db_pass" -h localhost --protocol=TCP -P "$db_port" --databases fava mysql_innodb_cluster_metadata --single-transaction --triggers --routines --events > /shared/fava/mysql-fava-with-gtid."$(date +%g%m%d-%H:%M:%S)".sql
        return 0
    else
        return 1
    fi
}

if ! db_backup "$db_port1"
then
    echo "Unable to backup fava DB using port $db_port1"
    if ! db_backup "$db_port2"
    then
        echo "Unable to backup fava DB using port $db_port2"
        echo "fava DB not found. Not backing up MySQL"
    fi
fi
