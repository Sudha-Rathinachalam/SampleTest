#!/bin/bash

exec 2>&1
set -x

if [ "$#" -ne 1 ]
then
    echo "Usage: $0 <path_to_mysql_data_dir>"
    exit 1
fi

datadir=$1

if [ "$datadir" == "/" ] || [[ "$datadir" =~ /shared/fava* ]]
then
    echo "Invalid datadir: $datadir"
    exit 1
fi

systemctl stop fava-controller fava fava-dhcp fava-dhcp6 fava-wsgi fava-wsgi-boot mysqld mysqlrouter

yum remove -y mysql-community*
yum remove -y mysql-shell*
yum remove -y mysql-router*

cd "$datadir" && rm -rf ./*
rm -rf /var/log/mysql*.log
rm -rf /var/lib/mysqlrouter; rm -rf /var/log/mysqlrouter
rm -rf /etc/mysqlrouter
rm -rf "$HOME/.my.cnf"
