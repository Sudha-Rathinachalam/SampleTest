#!/bin/bash
# shellcheck disable=SC2034 # Need to disable warning on usused variables because MacOS bash version is old and doesn't support associative arrays
# To generate icons locally: ./generate_favicons.sh [site] [outdir]


QCG='#c1531b'
QMF='#6c3b5d'
QMN='#9e28b5'
SNC='#003595'
WCZ='#009845'
WMX='#ef2ac1'
QCI='#ff5f00'
WHQ='#5b6670'

L10='#6cca98'
L11='#dbb7bb'
ORT='#84cadb'
ESIT='#ffb600'
HI5='#e0df00'
FAI='#ff8189'
TEST='#c8c8c8'

CONTROLLERS="\
QCG,L10,qcg,01,+0
QCG,L10,qcg,02,+0
QCG,L10,qcg,03,+0
QCG,L11,qcg,11,+0
QCG,L11,qcg,12,+0
QCG,L11,qcg,13,+0
QMF,ESIT,qmf,4,-4
QMF,L10,qmf,01,-4
QMF,L10,qmf,02,-4
QMF,L10,qmf,03,-4
QMF,L11,qmf,11,-4
QMF,L11,qmf,12,-4
QMF,L11,qmf,13,-4
QMF,L11,qmf,14,-4
QMF,L11,qmf,15,-4
QMF,L11,qmf,16,-4
QMF,L11,qmf,17,-4
QMF,L11,qmf,18,-4
QMF,L11,qmf,19,-4
QMF,L11,qmf,20,-4
QMF,L11,qmf,21,-4
QMF,L11,qmf,22,-4
QMF,L11,qmf,23,-4
QMF,L11,qmf,24,-4
QMF,L11,qmf,25,-4
QMF,ORT,qmf,1,-4
QMF,ORT,qmf,2,-4
QMF,ORT,qmf,3,-4
QMN,L10,qmn,01,+0
QMN,L10,qmn,02,+0
QMN,L10,qmn,03,+0
QMN,L10,qmn,04,+0
QMN,L10,qmn,05,+0
QMN,L10,qmn,06,+0
QMN,L11,qmn,11,+0
QMN,L11,qmn,12,+0
QMN,L11,qmn,13,+0
QMN,L11,qmn,14,+0
QMN,L11,qmn,15,+0
QMN,L11,qmn,16,+0
QMN,L11,qmn,17,+0
QMN,L11,qmn,18,+0
QMN,L11,qmn,19,+0
QMN,L11,qmn,20,+0
QMN,L11,qmn,21,+0
QMN,L11,qmn,22,+0
QMN,L11,qmn,23,+0
QMN,L11,qmn,24,+0
QMN,L11,qmn,25,+0
QMN,L11,qmn,26,+0
QMN,L11,qmn,27,+0
QMN,L11,qmn,28,+0
QMN,TEST,qmn,d1,+0
QMN,TEST,qmn,d2,+0
SNC,FAI,snc,f,+0
SNC,TEST,snc,1,+0
SNC,TEST,snc,2,+0
SNC,TEST,snc,3,+0
WCZ,ORT,wcz,01,+0
WCZ,ORT,wcz,02,+0
WMX,ESIT,wmx,4,+0
WMX,ORT,wmx,1,+0
WMX,ORT,wmx,2,+0
WMX,L10,wmx,01,+0
WMX,L10,wmx,02,+0
WMX,L10,wmx,03,+0
WMX,L11,wmx,11,+0
WMX,L11,wmx,12,+0
WMX,L11,wmx,13,+0
QCI,HI5,qci,1,+0
WHQ,HI5,whq,1,+0
SNC,TEST,test,01,+0"

function generate_icon() {
    # args: 1-OUTDIR, 2-SITE, 3-PROGRAM, 4-ROW1, 5-ROW2, 6-ADJUST
    if [ "$1" = "/usr/share/nginx/html" ]; then
        FONT="Liberation-Sans-Regular"
    else
        FONT="MicrosoftSansSerif"
    fi
    ICONFILE=${4}${5}.ico
    echo Creating icon "${1}/$ICONFILE"
    CMD="convert \
        -size 64x64 \
        canvas:\"${!2}\" \
        -fill \"${!3}\" \
        -draw 'roundrectangle 0,6 64,58 30,21' \
        -fill black \
        -font ${FONT} \
        -pointsize 30 \
        -gravity center \
        -annotate ${6}-9 ${4} \
        -annotate +0+15 ${5} \
        $1/$ICONFILE"
    eval "$CMD"
    echo "$CMD" > /tmp/a.txt
    if [ "$1" != "/usr/share/nginx/html" ]; then
        echo "<link rel=icon href=$ICONFILE>$ICONFILE</p>$CMD" | tr -s ' ' > "${1}/$ICONFILE.html"
        open -na "Google Chrome" --args "$PWD/${1}/$ICONFILE.html"
    fi
}

if [ "$2" ]; then
    OUTDIR="$2"
else
    OUTDIR=$(date +%y%m%d-%H%M%S)
fi
mkdir "$OUTDIR"

if [ "$1" ]; then
    PATTERN=$(echo "$1," | sed -e "s/[[:alpha:]]*/,&,/")
    CONTROLLERS=$(echo "$CONTROLLERS" | grep -o "[^ ]*${PATTERN}[^ ]*")
fi

if [ "$CONTROLLERS" ]; then
    for CONTROLLER in $CONTROLLERS; do
        # shellcheck disable=SC2086
        generate_icon "$OUTDIR" ${CONTROLLER//,/ }
    done
else
    echo Icon definitions for "$1" not available
    exit 1
fi
