Favicons installation
==

1. Update the variable in fbcode/opseng/fava_ansible/favicons/vars/favicons_vars.yaml file.

2. Run the following Ansible command

    ansible-playbook -i inventory -l <site name> favicons/favicons.yaml
