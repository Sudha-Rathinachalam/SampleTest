## Install and configure osquery using Ansible

Update the variables in osquery_vars.yml to match your environment. 
Run the following command(s) in this directory after updating the path to fava_hosts.yaml

#### To install osquery on all FAVA hosts

`ansible-playbook -i fava_inventory.yaml --limit fava osquery.yml --extra-vars @osquery_vars.yml`

#### To install osquery on non-lab FAVA sites

`ansible-playbook -i fava_inventory.yaml --limit fava.mfr osquery.yml --extra-vars @osquery_vars.yml`

#### To install osquery on only one host(wmx01)

`ansible-playbook -i fava_inventory.yaml --limit wmx01 osquery.yml --extra-vars @osquery_vars.yml`


#### Print osquery api_token.key from all FAVA sites

`ansible -i fava_inventory.yaml fava -m command -a "sh -c 'test -s /etc/osquery/api_token.key && cat /etc/osquery/api_token.key || echo No config'"`

#### Print osqueryd service status from all FAVA sites

`ansible -i fava_inventory.yaml fava -m shell -a "systemctl is-active --quiet osqueryd && echo osqueryd is running || (echo 'osqueryd is not running '; exit 1)"

