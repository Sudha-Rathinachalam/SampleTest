dhcpd installation and configuration
==

1. Update the variables in fbcode/opseng/fava_ansible/dhcpd/vars/dhcpd_vars.yaml file.

2. Run the following Ansible command

    ansible-playbook -i inventory -l <site name> dhcpd/dhcpd.yaml
