import re
import csv
import sys
import os
import mysql.connector

rex = re.compile(r'(- name: )(.*)')
test_name_list = []
test_name = []
test_result = []
testcase_csv_file = sys.argv[1] # Test case name from controller script
test_results_csv = sys.argv[2]  # result csv file after each run as what we are getting in email
html_final_report = sys.argv[3] # getting name from the command line for saving the csv file
i = 0
j = 0

with open(testcase_csv_file, "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    for row in csv_reader:
        print(row)
        test_name.append(row)

#with open("/home/facebook/USSDT-FULL-Suite.txt", "r+") as read_content:
#    content = read_content.read()
#    print(content)
#    test_name_list = rex.findall(content.strip())
#    print(test_name_list)

#for name in test_name_list:
#    test_name.append(test_name_list[i][1])
#    i += 1

print("name list value is {} : ".format(test_name))
print(len(test_name))

with open(test_results_csv, "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    for row in csv_reader:
        print(row)
        test_result.append(row[3])

print("Test Results are {}".format(test_result))

db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()
cur.execute("show tables")

for (name) in cur:
    print("Tables are {}".format(name))

for test in test_name:
    for name in test:
        print("Test case names are {}".format(name))

where_stmt = " where Date=CURDATE()"
#result = test_result[j]
#print("Result var value is {}".format(result))
for test in test_name:
    for name in test:
        print(name)
        sql = 'INSERT INTO Device_Dummy_Suite (Device, TestSuite, Date, Result, TestCases) VALUES ("BC","USSDT_Full",CURDATE(),"{}","{}")'.format(test_result[j],name)
#    sql2 = 'update Device_Dummy_Suite set TestCases=("{}")'.format(name) + where_stmt
#    sql1 = 'INSERT INTO Device_Dummy_Suite (TestCases) VALUES ("{}")'.format(name) + where_stmt
        print("sql1 stmt is {}".format(sql))
        cur.execute(sql)
#    cur.execute(sql2)
#    cur.execute(sql1)
        j += 1

db_con.commit()

dbQuery='SELECT Device, TestSuite, Date, TestCases, Result FROM Device_Dummy_Suite;'
cur.execute(dbQuery)
result=cur.fetchall()
result_csv = csv.writer(open(html_final_report, "w+"))
for row in result:
    print("row csv value is {}".format(row))
    result_csv.writerow(row)

cur.execute("SELECT distinct(Date) FROM Device_Dummy_Suite")

# print all the first cell of all the rows
for row in cur.fetchall():
    print row[0]

cur.close()

db_con.close()

