# import pandas and matplotlib 
import  pandas as pd 
import matplotlib.pyplot as plt 
  
# create 2D array of table given above 
data = [[15, 8, 7]       
       ] 
  
# dataframe created with 
# the above data array 
df = pd.DataFrame(data, columns = ['No. Of Test Cases', 'Passed',  
                                    'Failed'] ) 
  
df.plot.bar() 
  
# plot between 2 attributes 
plt.bar(df['No. Of Test Cases'], df['Passed'], df['Failed']) 
plt.xlabel("Build") 
plt.ylabel("No. Of Test Cases") 
plt.show()
