import re
import csv
import sys
import os
import mysql.connector

rex = re.compile(r'(- name: )(.*)')
test_name_list = []
test_name = []
test_result = []
i = 0
j = 0

with open("/home/facebook/USSDT-FULL-Suite.txt", "r+") as read_content:
    content = read_content.read()
#    print(content)
    test_name_list = rex.findall(content.strip())
    print(test_name_list)

for name in test_name_list:
    test_name.append(test_name_list[i][1])
    i += 1

print("name list value is {} : ".format(test_name))
print(len(test_name))

with open("/home/facebook/csv_dynamic.csv", "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    for row in csv_reader:
        print(row)
        test_result.append(row[3])

print("Test Results are {}".format(test_result))

db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()
cur.execute("show tables")

for (name) in cur:
    print("Tables are {}".format(name))

for name in test_name:
    print("Test case names are {}".format(name))

where_stmt = " where Date=CURDATE()"
#result = test_result[j]
#print("Result var value is {}".format(result))
for name in test_name:
    print(name)
    sql = 'INSERT INTO Device_Dummy_Suite (Device, TestSuite, Date, Result, TestCases) VALUES ("BC","USSDT_Full",CURDATE(),"{}","{}")'.format(test_result[j],name)
#    sql2 = 'update Device_Dummy_Suite set TestCases=("{}")'.format(name) + where_stmt
#    sql1 = 'INSERT INTO Device_Dummy_Suite (TestCases) VALUES ("{}")'.format(name) + where_stmt
    print("sql1 stmt is {}".format(sql))
    cur.execute(sql)
#    cur.execute(sql2)
#    cur.execute(sql1)
    j += 1

db_con.commit()

cur.close()

db_con.close()
