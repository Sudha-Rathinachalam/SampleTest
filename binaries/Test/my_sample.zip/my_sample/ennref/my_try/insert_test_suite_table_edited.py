import re
import csv
import sys
import os
import mysql.connector

import writing_html_mod

date_list = []
db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()

cur.execute("SELECT distinct(Date) FROM UBMCT_YV2_Test_Suite order by Date DESC")

date_result = cur.fetchall()
date_result_csv = csv.writer(open("/home/facebook/html_report_split_date.csv", "w+"))
for row in date_result:
    print("row csv value is {}".format(row))
    date_list.append(row)
    date_result_csv.writerow(row)

print("row list value is {}".format(date_list))

list_length = len(date_list)
i = 0
csv_file_name = "/home/facebook/csv_for_html"
csv_format = ".csv"
html_file_name = "/home/facebook/cumulative_report_"
html_format = ".html"
 # writing to csv file

with open("/home/facebook/html_report_split.csv", "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    print(csv_reader)
    print("inside /home/facebook/html_report_split_date.csv")
    for row in csv_reader:
        print("row value in file is {}".format(row))
        for date_tuple in row:
#            unique_date = "'" + date_tuple + "'"
#            print(unique_date)
            dbQuery="SELECT Date, Device, TestSuite, TestCases, Result FROM UBMCT_YV2_Test_Suite where Date={}".format("'" + date_tuple + "'")
#            sql = 'INSERT INTO Device_Dummy_Suite (Device, TestSuite, Date, Result, TestCases) VALUES ("BC","USSDT_Full",CURDATE(),"{}","{}")'.format(test_result[j],name)
            print("query value is: {}".format(dbQuery))
            cur.execute(dbQuery)
            result=cur.fetchall()
            print("result value is: {}".format(result))
#            with open(csv_file_name + csv_format, append_write) as write_csv:
#            query_result_csv = csv.writer(open(csv_file_name + csv_format, append_write))
#            for output in result:
#                query_result_csv.writerow(output)
#                csv_writer = csv.writer(write_csv)
#                for output in result:
#                    print("output value is: {}".format(output))
#                    csv_writer.writerow(output)
#                csv_writer.writerow('\n')#                result_csv = csv.writer(open(csv_file_name + i + csv_format, "w+"))
            csv_file_name_append = csv_file_name + date_tuple + csv_format
            with open(csv_file_name_append, "w+") as csv_write:
            	result_csv = csv.writer(csv_write)
            	for output in result:
                	print("output value is: {}".format(output))
                	result_csv.writerow(output)
            writing_html_mod.input_csv_output_html(csv_file_name_append, html_file_name + date_tuple, html_format)
            i += 1

cur.close()

db_con.close()
