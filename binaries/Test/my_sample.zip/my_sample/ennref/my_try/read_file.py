import csv

csv_file_name_append = "/home/facebook/csv_for_html2020-01-23.csv"
reader_html = csv.reader(open(csv_file_name_append, "r+"))

          # Create the HTML file
for print_csv in reader_html:
    print("csv value inside html is:  {}").format(print_csv)

