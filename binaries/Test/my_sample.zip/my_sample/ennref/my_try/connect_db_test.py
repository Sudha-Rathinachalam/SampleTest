import mysql.connector 
 
dbcon = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins') 
cur = dbcon.cursor() 
cur.execute("show tables")
for (name) in cur:
    print("{}".format(name))
dbcon.close()
