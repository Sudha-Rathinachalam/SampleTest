import re
import csv
import sys
import os
import mysql.connector

date_list = []
db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()

cur.execute("SELECT distinct(Date) FROM UBMCT_YV2_Test_Suite order by Date DESC")

date_result = cur.fetchall()
date_result_csv = csv.writer(open("/home/facebook/html_report_split_date.csv", "w+"))
for row in date_result:
    print("row csv value is {}".format(row))
    date_list.append(row)
    date_result_csv.writerow(row)

print("row list value is {}".format(date_list))

list_length = len(date_list)
i = 0
csv_file_name = "/home/facebook/csv_for_html"
csv_format = ".csv"

 # writing to csv file

with open("/home/facebook/html_report_split_date.csv", "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    for row in csv_reader:
        for date_tuple in row:
            if os.path.exists(csv_file_name + csv_format):
                print("inside if")
                append_write = "a+"  # append if already exists
            else:
                print("inside else")
                append_write = "w+"  # make a new file if not
#            unique_date = "'" + date_tuple + "'"
#            print(unique_date)
            dbQuery="SELECT Date, Device, TestSuite, TestCases, Result FROM UBMCT_YV2_Test_Suite where Date={}".format("'" + date_tuple + "'")
#            sql = 'INSERT INTO Device_Dummy_Suite (Device, TestSuite, Date, Result, TestCases) VALUES ("BC","USSDT_Full",CURDATE(),"{}","{}")'.format(test_result[j],name)
            print("query value is: {}".format(dbQuery))
            cur.execute(dbQuery)
            result=cur.fetchall()
            print("result value is: {}".format(result))
            with open(csv_file_name + csv_format, append_write) as write_csv:
#            query_result_csv = csv.writer(open(csv_file_name + csv_format, append_write))
#            for output in result:
#                query_result_csv.writerow(output)
                csv_writer = csv.writer(write_csv)
                for output in result:
                    print("output value is: {}".format(output))
                    csv_writer.writerow(output)
                csv_writer.writerow('\n')
#                result_csv = csv.writer(open(csv_file_name + i + csv_format, "w+"))
#	        i += 1

cur.close()

db_con.close()
