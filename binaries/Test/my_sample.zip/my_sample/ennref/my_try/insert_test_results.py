import re
import csv
import sys
import os
import mysql.connector

rex = re.compile(r'(- name: )(.*)')
test_name_list = []
test_name = []
i = 0
j = 0

with open("/home/facebook/USSDT-FULL-Suite.txt", "r+") as read_content:
    content = read_content.read()
    print(content)
    test_name_list = rex.findall(content.strip())
    print(test_name_list)

for name in test_name_list:
    test_name.append(test_name_list[i][1])
    i += 1

print("name list value is {} : ".format(test_name))
print(len(test_name))

db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()
cur.execute("show tables")

for (name) in cur:
    print("{}".format(name))

for name in test_name:
    print(name)
    sql = "INSERT INTO USSDT_BC_Test_Suite (Device, TestSuite) VALUES ('BC','USSDT_Full')"
    sql1 = "INSERT INTO USSDT_BC_Test_Suite (TestCases) VALUES (%s)" (name)
    cur.execute(sql)
    cur.execute(sql1)
    j += 1
    db_con.commit()

cur.close()

db_con.close()
