import re
import csv
import sys
import os
import mysql.connector

date_list = []
db_con = mysql.connector.connect(user='root',password='Facebook@123',host='localhost', database='jenkins')
cur = db_con.cursor()

cur.execute("SELECT distinct(Date) FROM UBMCT_YV2_Test_Suite order by Date DESC")

date_result = cur.fetchall()
date_result_csv = csv.writer(open("/home/facebook/html_report_split.csv", "w+"))
for row in date_result:
    print("row csv value is {}".format(row))
    date_list.append(row)
    date_result_csv.writerow(row)

print("row list value is {}".format(date_list))

list_length = len(date_list)
i = 0
csv_file_name = "/home/facebook/csv_for_html",

with open("/home/facebook/html_report_split.csv", "r+") as read_csv:
    csv_reader = csv.reader(read_csv)
    for row in csv_reader:
        print(row)
        dbQuery='SELECT Device, TestSuite, Date, TestCases, Result FROM UBMCT_YV2_Test_Suite where Date=row;'
        cur.execute(dbQuery)
	result=cur.fetchall()
	result_csv = csv.writer(open(csv_file_name + ".csv", "w+"))
	i += 1
		
	
cur.close()

db_con.close()

#sql = 'INSERT INTO Device_Dummy_Suite (Device, TestSuite, Date, Result, TestCases) VALUES ("BC","USSDT_Full",CURDATE(),"{}","{}")'.format(test_result[j],name)
