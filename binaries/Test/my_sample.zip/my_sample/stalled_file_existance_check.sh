[facebook@facebookwiki jenkins-cli-jar]$ cat stalled_file_existance_check.sh
password="pass\!Q\@W\#E"
count=0
flag="False"

server="root@10.1.1.10"

declare -a array1=('root@10.1.1.10');

if ssh -q "$server" "test -f /root/dut_list.txt"; then
    echo $password | sudo -S scp "$server:/root/dut_list.txt" /home/facebook/jenkins-cli-jar/
fi

while read -r dut; do
    echo $dut
    if ssh -q "$server" "test -f /root/$dut/stalled_html_file.html"; then
        echo $password | sudo -S scp "$server:/root/$dut/stalled_html_file.html" /home/facebook/jenkins-cli-jar/
        (
            echo "From: jenkinsodc@fb.localdomain"
            echo "To: sudha.r@hcl.com"
            echo "Subject: The following test is stalled"
            echo "Content-Type: text/html"
            echo
            cat /home/facebook/jenkins-cli-jar/stalled_html_file.html
        ) | sendmail -t
            return_code=$(echo $?)
            if [ $return_code -eq 0 ]
            then
                flag="True"
            fi
#        cat /home/facebook/jenkins-cli-jar/stalled_html_file.html | mail -s "The following test is stalled" -r jenkinsodc@fb.localdomain sudha.r@hcl.com
#    else
#        echo 'File does not exist.'
    fi

    return_code=$(echo $?)
    echo "$flag"
    if [ "$flag" = "True" ]
    then
       echo "MAIL SENT"
       ssh -q "$i" "rm -f /root/stalled_html_file.html"
       if [ $return_code -eq 0 ]
       then
          echo "File Deleted!"
       fi
#       if ssh -q "$i" "test -f /root/stalled_html_file.html"; then
#           echo $password | sudo -S rm -f /root/stalled_html_file.html
#       fi
    fi
done < /home/facebook/jenkins-cli-jar/dut_list.txt
You have new mail in /var/spool/mail/facebook
[facebook@facebookwiki jenkins-cli-jar]$
