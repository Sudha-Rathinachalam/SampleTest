#!/bin/bash
#echo "inside controller"

dut=$1
logfile=$2
csvfile=$3
htmlfile=$4
taskLogFile=$5
testsuitename=$6
test_suite=$7
#favacli.py run testsuite  --ignore-bom-check --db-creds /root/dbcreds -s $dut -f UBOOTT-Regression_smart_impact_on_perf
#job_id=$(mysql fava -se 'select id from job where data like "%UBOOTT-Regression_smart_impact_on_perf%" order by id DESC limit 1;')
#job_id=$(mysql fava -se 'select id from job where data like "'$testsuitename'" order by id DESC limit 1;')
#echo $job_id
job_id=299
state=$(mysql fava -se 'select state from job where id='$job_id' order by id DESC limit 1;')
echo $state
task_id=$(mysql fava -se 'select id from task where job_id='$job_id'')
echo $task_id
if [ "$state" = "queued" ]
then
   sleep 2m
   state=$(mysql fava -se 'select state from job where id='$job_id' order by id DESC limit 1;')
fi
if [ "$state" = "started" ]
then
   echo "inside first if"
   while [ "$state" = "started" ]
   do
     echo "inside while"
     sleep 2m
     state=$(mysql fava -se 'select state from job where id='$job_id' order by id DESC limit 1;')
     echo $state
     if [ "$state" = "started" ]
     then
        echo "before continue"
        continue
     elif [ "$state" = "completed" ]
     then
            task_id=$(mysql fava -se 'select id from task where job_id='$job_id';')
        break
     fi
   done
fi
if [ "$state" = "killed" ]
then
   task_id=$(mysql fava -se 'select id from task where job_id='$job_id';')
else
   echo "Invalid State"
fi
echo $task_id
task_state=$(mysql fava -se 'select state from task where job_id='$job_id' and state="stalled" order by id DESC limit 1;')
if [ "$task_state" = "stalled" ]
then
   sleep 5m
fi
> /root/$logfile
> /root/$dut/$csvfile
#python /root/create_csv_dynamic.py /root/$dut/$csvfile
my_array=($(echo $task_id | tr " " "\n"))
i=0
echo "${my_array[@]}"
for t in "${my_array[@]}"
do
    echo "in for"
    echo $t
    url="J"$job_id"T"$t
    echo $url
    cat /shared/fava/logs/$dut/$url/STDERR >> /root/$logfile
    cat /shared/fava/logs/$dut/$url/STDERR > /root/dummy_logs/$dut/$taskLogFile
    python /root/_to_csv_dynamic.py  /root/dummy_logs/$dut/$taskLogFile /root/$dut/$csvfile
done
echo "Read file content!"
export taskidList=${my_array[0]}
for i in "${my_array[@]:1}"; do
   taskidList+=,$i
done
echo "${my_array[@]}"
echo $taskidList
#python /root/_to_csv.py /root/output_file_UBMCT_TP.csv
#python /root/_to_csv_dynamic.py $logfile $csvfile
#python /root/csv_to_html.py /root/output_file_UBMCT_TP.csv /root/output_file_UBMCT_TP.html $taskidList $job_id
python /root/_to_html_dynamic.py /root/$dut/$csvfile /root/$htmlfile $taskidList $job_id $dut
