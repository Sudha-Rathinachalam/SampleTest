import csv
import sys

if len(sys.argv) < 2:
   # print("Usage: ./csv-html.py <your CSV file> <your HTML File.html>")
    print("Usage: ./csv_to_html.py  output_file_UBT_BC.csv output_file_UBT_BC.html")
    print()
    print()
    exit(0)
array_list=[]
array_list_onsite = []
#if len(sys.argv) < 3:
    #array_list=[3:]
array_list = sys.argv[3]
print(array_list)
array_lists=array_list.split(',')
print(array_lists)
job_id = sys.argv[4]
print(job_id)
dut = sys.argv[5]
print(dut)
modified_list = []
#array_list = ["J312T420", "J312T421", "J312T422"]
#array_list = sys.argv[3]
#print(array_list)
#my_string = "https://10.161.113.138/logs/QTXSP91902327/J"+job_id+"T"
#my_string_onsite =  "https://192.8.225.110/logs/QT1PL92401708/J"+job_id+"T"

my_string = "https://10.161.113.178/logs/"+dut+"/J"+job_id+"T"
print(my_string)
my_string_onsite =  "https://192.8.225.110/logs/"+dut+"/J"+job_id+"T"
print(my_string_onsite)
#job_ids="J"+job_id+"T"
array_list = [my_string+s for s in array_lists]
array_list_onsite = [my_string_onsite+s for s in array_lists]
print (array_list_onsite)
print(array_list)
alen = len(array_list)
print(alen)
blen = len(array_list_onsite)
print(blen)
i = 0
j = 0

# Open the CSV file for reading
reader = csv.reader(open(sys.argv[1]))

# Create the HTML file
f_html = open(sys.argv[2], "w");
f_html.write('<html>')
f_html.write('<title>Regression Result</title>')
f_html.write('<head>')
f_html.write('<style> table, th, td { border: 1px solid black;}</style>')
f_html.write('</head>')
f_html.write('<body>')
f_html.write('<table border = "1">');
f_html.write('<colgroup> <col span="6" style="background-color:pink"> </colgroup>')
f_html.write('<tr><th>Test Case Name</th>'
             '   <th>Test Summary</th>'
             '   <th>Passed Steps</th>'
             '   <th>Failed Steps</th>'
             '   <th>Test Result</th>'
             '   <th>Logs(Local-Access)</th>'
             '   <th>Logs(FB-Access)</b></th>'
             '</tr>')

for row in reader:  # Read a single row from the CSV file
    f_html.write('<tr>');  # Create a new row in the table
    for column in row:  # For each column..
        f_html.write('<td>' + column + '</td>');
    if i < alen:
        f_html.write('<td><a href = " ' + array_list[i] + ' "> Click here </a></td>')
                #f_html.write('<td><a href = " ' + array_list_onsite[i] + ' "> Click here </a></td>')
        i += 1
    if j < blen:
        f_html.write('<td><a href = " ' + array_list_onsite[j] + ' "> Click here </a></td>')
        j += 1
    #f_html.write('</tr>')
    #f_html.write('<tr>');
    #for column in row:
     #   f_html.write('<td>' + column + '</td>');
    #if j < blen:
     #   f_html.write('<td><a href = " ' + array_list_onsite[j] + ' "> Click here </a></td>')
#       j += 1
    f_html.write('</tr>')
    f_html.write('<br\>');
f_html.write('</table>')
f_html.write('</body>')
f_html.write('</html>')
