import re
import csv
import sys
import os
from itertools import islice


# file_name  = sys.argv[2]
# appended_file_name = "C:\\Users\\mathavirajasekaranr\\Documents\\input_file\\"+ file_name
# contents = open(appended_file_name,"w+")
rex = re.compile(r'''(Test\s+Summary:
                       |Passed\s+Steps:
                       |Failed\s+Steps:
                       |Test\s+Result
                     )
                     \s*:?\s*
                     (.*)
                     ''', re.VERBOSE)
test_dict = {}
test_list = []
final_list = []
print(len(test_list))
list_length = len(test_list)
n=4
#length_to_split = [4, 4, 4, 4]
# specifying the fields for csv file
fields = ['Test Summary', 'Passed Steps', 'Failed Steps', 'Test Result']
log_file = sys.argv[1]
input_csv_file = sys.argv[2]

#with open(input_csv_file, "w+") as csv_file:
#    writer = csv.writer(csv_file)
#    writer.writerow(fields)

def save_to_csv(values):
    # writing to csv file
    if os.path.exists(input_csv_file):
        append_write = "a+" # append if already exists
    else:
        append_write = "w+" # make a new file if not
    with open(input_csv_file, append_write) as csv_file:
        # creating a csv dict writer object
        writer = csv.writer(csv_file)
        # writing headers (field names)
        # writing data rows
#        writer.writerow(fields)
        for i in values:
            print("inside csv for i value is {} ".format(i))
            writer.writerow(i)
na_string="N/A"
#input_file=open("C:\\Users\\mathavirajasekaranr\\Documents\\input_file\\input_file.txt","r+")
count=0
with open(log_file, "r+") as read_content:
    content=read_content.read()
    print(content)
    m = rex.findall(content)
    if len(m) == 0:
        m=["NA"]*4
        for result in m:
            test_list.append(result)
    # print(m)
    else:
        for result in m:
            test_list.append(result[1])
#    m = rex1.search(content)
#     if 'Test Summary:' in content:
#         test_dict["Test Summary"] = m.group(2)
#         test_list.append(m.group(2))
#         print(m.group(2))
#         count+=1
#     if 'Passed Steps:' in content:
#         test_dict["Passed Steps"] = m.group(2)
#         test_list.append(m.group(2))
#         print(m.group(2))
#         count += 1
#     if 'Failed Steps:' in content:
#         test_dict["Failed Steps"] = m.group(2)
#         test_list.append(m.group(2))
#         print(m.group(2))
#         count += 1
#     if 'Test Result:' in content:
#         test_dict["Test Result"] = m.group(2)
#         test_list.append(m.group(2))
#         print(m.group(2))
#         count += 1
#
# if count == 0:
#     while count < 4 :
#         test_list.append("N/A")
#         count += 1
#         print(count)
print("test_list value in csv file is {} ".format(test_list))
            #save_to_csv(m.group(2))
        #save_to_csv(test_list)
#Inputt = iter(test_list)
Inputt = test_list
#Output = [list(islice(Inputt, elem))
#          for elem in length_to_split]
Output=[Inputt[i:i+n] for i in range(0, len(Inputt), n)]
print("Output value is {} ".format(Output))
save_to_csv(Output)
