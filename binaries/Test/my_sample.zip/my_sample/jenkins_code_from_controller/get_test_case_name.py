import re
import csv
import sys
import os
from itertools import islice

rex = re.compile(r'("name":\s?)("\w+")')
test_name_list = []
test_name = []
split_test_case = []
csv_list = []
testcase_json = sys.argv[1] # testcases file as json which comes from shell script
test_case_csv_file = sys.argv[2] # File to save testcase names
i=0
with open(testcase_json, "r+") as read_content:
    content = read_content.read()
#    print(content)
    test_name_list = rex.findall(content.strip())

for name in test_name_list:
    test_name.append(test_name_list[i][1])
    i += 1

for name in test_name:
    split_test_case.append(name.strip('"'))

for element in split_test_case:
        sub = element.split(', ')
        csv_list.append(sub)

def save_to_csv(list_value):
    # writing to csv file
#    if os.path.exists(test_case_csv_file):
#        append_write = "a+"  # append if already exists
#    else:
#        append_write = "w+"  # make a new file if not
    with open(test_case_csv_file, "w+") as csv_file:
        # creating a csv dict writer object
        writer = csv.writer(csv_file)
        # writing headers (field names)
        # writing data rows
        #        writer.writerow(fields)
        for i in list_value:
            writer.writerow(i)

save_to_csv(csv_list)

